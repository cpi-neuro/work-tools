#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2024.2.1),
    on Juli 14, 2025, at 14:27
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER, priority)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard
from psychopy_bids.bids import BIDSBehEvent
from psychopy_bids.bids import BIDSTaskEvent
from psychopy_bids.bids import BIDSError
from psychopy_bids.bids import BIDSHandler

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2024.2.1'
expName = 'cva25_con_OD'  # from the Builder filename that created this script
# information about this experiment
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1280, 1024]
# [1536, 864]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version='',
        extraInfo=expInfo, runtimeInfo=None,
        originPath='C:\\Users\\Carmen\\Desktop\\TDA\\cva25_con_OD.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowStencil=False,
            monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='height', 
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [0,0,0]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'height'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.mouseVisible = False
    win.hideMessage()
    # show a visual indicator if we're in piloting mode
    if PILOTING and prefs.piloting['showPilotingIndicator']:
        win.showPilotingIndicator()
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    
    # Setup iohub keyboard
    ioConfig['Keyboard'] = dict(use_keymap='psychopy')
    
    # Setup iohub experiment
    ioConfig['Experiment'] = dict(filename=thisExp.dataFileName)
    
    # Start ioHub server
    ioServer = io.launchHubServer(window=win, **ioConfig)
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='iohub'
        )
    if deviceManager.getDevice('key_HTLF_OD') is None:
        # initialise key_HTLF_OD
        key_HTLF_OD = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_HTLF_OD',
        )
    if deviceManager.getDevice('key_HTLU_OD') is None:
        # initialise key_HTLU_OD
        key_HTLU_OD = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_HTLU_OD',
        )
    if deviceManager.getDevice('key_HTRF_OD') is None:
        # initialise key_HTRF_OD
        key_HTRF_OD = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_HTRF_OD',
        )
    if deviceManager.getDevice('key_HTRU_OD') is None:
        # initialise key_HTRU_OD
        key_HTRU_OD = deviceManager.addDevice(
            deviceClass='keyboard',
            deviceName='key_HTRU_OD',
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], playbackComponents=[]):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    playbackComponents : list, tuple
        List of any components with a `pause` method which need to be paused.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    for comp in playbackComponents:
        comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='ioHub',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    for comp in playbackComponents:
        comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ioHub'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    if expInfo['session']:
        bids_handler = BIDSHandler(dataset='bids_cva25_con_OD',
         subject=expInfo['participant'], task=expInfo['expName'],
         session=expInfo['session'], data_type='func', acq='',
         runs=True)
    else:
        bids_handler = BIDSHandler(dataset='bids_cva25_con_OD',
         subject=expInfo['participant'], task=expInfo['expName'],
         data_type='func', acq='', runs=True)
    bids_handler.createDataset()
    bids_handler.addLicense('CC-BY-NC-4.0', force=True)
    bids_handler.addTaskCode(force=True)
    bids_handler.addEnvironment()
    
    # --- Initialize components for Routine "Trigger" ---
    # Run 'Begin Experiment' code from code_trigger
    from psychopy.hardware.emulator import launchScan
    
    v_MRinfo = { 'TR': 1.6,
                            'sync': '6',
                            'volumes':80, # 225
                            'sound': False,
                            'skip': 0}
    launchScan(win=win, settings=v_MRinfo, globalClock=core. Clock(), mode='scan', wait_msg='syncing')
    
    # --- Initialize components for Routine "HTLF_OD" ---
    image1_HTLF_OD = visual.ImageStim(
        win=win,
        name='image1_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_001.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image2_HTLF_OD = visual.ImageStim(
        win=win,
        name='image2_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_002.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    image3_HTLF_OD = visual.ImageStim(
        win=win,
        name='image3_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_003.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    image4_HTLF_OD = visual.ImageStim(
        win=win,
        name='image4_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_004.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    image5_HTLF_OD = visual.ImageStim(
        win=win,
        name='image5_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_005.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-4.0)
    image6_HTLF_OD = visual.ImageStim(
        win=win,
        name='image6_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_006.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-5.0)
    image7_HTLF_OD = visual.ImageStim(
        win=win,
        name='image7_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_007.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-6.0)
    image8_HTLF_OD = visual.ImageStim(
        win=win,
        name='image8_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_008.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-7.0)
    image9_HTLF_OD = visual.ImageStim(
        win=win,
        name='image9_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_009.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-8.0)
    image10_HTLF_OD = visual.ImageStim(
        win=win,
        name='image10_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_010.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-9.0)
    image11_HTLF_OD = visual.ImageStim(
        win=win,
        name='image11_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_011.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-10.0)
    image12_HTLF_OD = visual.ImageStim(
        win=win,
        name='image12_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_012.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-11.0)
    image13_HTLF_OD = visual.ImageStim(
        win=win,
        name='image13_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_013.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-12.0)
    image14_HTLF_OD = visual.ImageStim(
        win=win,
        name='image14_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_014.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-13.0)
    image15_HTLF_OD = visual.ImageStim(
        win=win,
        name='image15_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_015.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-14.0)
    image16_HTLF_OD = visual.ImageStim(
        win=win,
        name='image16_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_016.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-15.0)
    image17_HTLF_OD = visual.ImageStim(
        win=win,
        name='image17_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_017.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-16.0)
    image18_HTLF_OD = visual.ImageStim(
        win=win,
        name='image18_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_018.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-17.0)
    image19_HTLF_OD = visual.ImageStim(
        win=win,
        name='image19_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_019.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-18.0)
    image20_HTLF_OD = visual.ImageStim(
        win=win,
        name='image20_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_020.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-19.0)
    image21_HTLF_OD = visual.ImageStim(
        win=win,
        name='image21_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_021.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-20.0)
    image22_HTLF_OD = visual.ImageStim(
        win=win,
        name='image22_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_022.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-21.0)
    image23_HTLF_OD = visual.ImageStim(
        win=win,
        name='image23_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_023.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-22.0)
    image24_HTLF_OD = visual.ImageStim(
        win=win,
        name='image24_HTLF_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_024.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-23.0)
    image_Frame_HTLF_OD = visual.ImageStim(
        win=win,
        name='image_Frame_HTLF_OD', units='norm', 
        image='images/light_blue_frame_overlay.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2, 2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-24.0)
    image_Cue_HTLF_OD = visual.ImageStim(
        win=win,
        name='image_Cue_HTLF_OD', 
        image='images/ArrowLeft.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-25.0)
    image_Cross_HTLF_OD = visual.ImageStim(
        win=win,
        name='image_Cross_HTLF_OD', 
        image='images/Cross.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-26.0)
    image_Tar_HTLF_OD = visual.ImageStim(
        win=win,
        name='image_Tar_HTLF_OD', 
        image='images/Target.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=(0.1, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=True, flipVert=False,
        texRes=128.0, interpolate=True, depth=-27.0)
    key_HTLF_OD = keyboard.Keyboard(deviceName='key_HTLF_OD')
    
    # --- Initialize components for Routine "Break" ---
    image_Frame_Break = visual.ImageStim(
        win=win,
        name='image_Frame_Break', units='norm', 
        image='images/light_blue_frame_overlay.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2, 2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_Cross_Break = visual.ImageStim(
        win=win,
        name='image_Cross_Break', 
        image='images/Cross.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "HTLU_OD" ---
    image1_HTLU_OD = visual.ImageStim(
        win=win,
        name='image1_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_001.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image2_HTLU_OD = visual.ImageStim(
        win=win,
        name='image2_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_002.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    image3_HTLU_OD = visual.ImageStim(
        win=win,
        name='image3_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_003.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    image4_HTLU_OD = visual.ImageStim(
        win=win,
        name='image4_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_004.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    image5_HTLU_OD = visual.ImageStim(
        win=win,
        name='image5_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_005.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-4.0)
    image6_HTLU_OD = visual.ImageStim(
        win=win,
        name='image6_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_006.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-5.0)
    image7_HTLU_OD = visual.ImageStim(
        win=win,
        name='image7_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_007.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-6.0)
    image8_HTLU_OD = visual.ImageStim(
        win=win,
        name='image8_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_008.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-7.0)
    image9_HTLU_OD = visual.ImageStim(
        win=win,
        name='image9_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_009.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-8.0)
    image10_HTLU_OD = visual.ImageStim(
        win=win,
        name='image10_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_010.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-9.0)
    image11_HTLU_OD = visual.ImageStim(
        win=win,
        name='image11_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_011.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-10.0)
    image12_HTLU_OD = visual.ImageStim(
        win=win,
        name='image12_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_012.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-11.0)
    image13_HTLU_OD = visual.ImageStim(
        win=win,
        name='image13_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_013.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-12.0)
    image14_HTLU_OD = visual.ImageStim(
        win=win,
        name='image14_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_014.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-13.0)
    image15_HTLU_OD = visual.ImageStim(
        win=win,
        name='image15_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_015.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-14.0)
    image16_HTLU_OD = visual.ImageStim(
        win=win,
        name='image16_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_016.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-15.0)
    image17_HTLU_OD = visual.ImageStim(
        win=win,
        name='image17_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_017.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-16.0)
    image18_HTLU_OD = visual.ImageStim(
        win=win,
        name='image18_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_018.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-17.0)
    image19_HTLU_OD = visual.ImageStim(
        win=win,
        name='image19_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_019.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-18.0)
    image20_HTLU_OD = visual.ImageStim(
        win=win,
        name='image20_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_020.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-19.0)
    image21_HTLU_OD = visual.ImageStim(
        win=win,
        name='image21_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_021.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-20.0)
    image22_HTLU_OD = visual.ImageStim(
        win=win,
        name='image22_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_022.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-21.0)
    image23_HTLU_OD = visual.ImageStim(
        win=win,
        name='image23_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_023.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-22.0)
    image24_HTLU_OD = visual.ImageStim(
        win=win,
        name='image24_HTLU_OD', units='norm', 
        image='images/pattern_images_rec_half_left/pattern_024.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-23.0)
    iamge_Frame_HTLU_OD = visual.ImageStim(
        win=win,
        name='iamge_Frame_HTLU_OD', units='norm', 
        image='images/light_blue_frame_overlay.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2, 2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-24.0)
    image_Cue_HTLU_OD = visual.ImageStim(
        win=win,
        name='image_Cue_HTLU_OD', 
        image='images/ArrowRight.png', mask=None, anchor='center',
        ori=0.0, pos=(0.002, 0.0015), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-25.0)
    image_Cross_HTLU_OD = visual.ImageStim(
        win=win,
        name='image_Cross_HTLU_OD', 
        image='images/Cross.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-26.0)
    image_Tar_HTLU_OD = visual.ImageStim(
        win=win,
        name='image_Tar_HTLU_OD', 
        image='images/Target.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=(0.1, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=True, flipVert=False,
        texRes=128.0, interpolate=True, depth=-27.0)
    key_HTLU_OD = keyboard.Keyboard(deviceName='key_HTLU_OD')
    
    # --- Initialize components for Routine "Break" ---
    image_Frame_Break = visual.ImageStim(
        win=win,
        name='image_Frame_Break', units='norm', 
        image='images/light_blue_frame_overlay.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2, 2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_Cross_Break = visual.ImageStim(
        win=win,
        name='image_Cross_Break', 
        image='images/Cross.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "HTRF_OD" ---
    image1_HTRF_OD = visual.ImageStim(
        win=win,
        name='image1_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_001.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image2_HTRF_OD = visual.ImageStim(
        win=win,
        name='image2_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_002.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    image3_HTRF_OD = visual.ImageStim(
        win=win,
        name='image3_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_003.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    image4_HTRF_OD = visual.ImageStim(
        win=win,
        name='image4_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_004.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    image5_HTRF_OD = visual.ImageStim(
        win=win,
        name='image5_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_005.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-4.0)
    image6_HTRF_OD = visual.ImageStim(
        win=win,
        name='image6_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_006.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-5.0)
    image7_HTRF_OD = visual.ImageStim(
        win=win,
        name='image7_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_007.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-6.0)
    image8_HTRF_OD = visual.ImageStim(
        win=win,
        name='image8_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_008.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-7.0)
    image9_HTRF_OD = visual.ImageStim(
        win=win,
        name='image9_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_009.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-8.0)
    image10_HTRF_OD = visual.ImageStim(
        win=win,
        name='image10_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_010.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-9.0)
    image11_HTRF_OD = visual.ImageStim(
        win=win,
        name='image11_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_011.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-10.0)
    image12_HTRF_OD = visual.ImageStim(
        win=win,
        name='image12_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_012.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-11.0)
    image13_HTRF_OD = visual.ImageStim(
        win=win,
        name='image13_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_013.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-12.0)
    image14_HTRF_OD = visual.ImageStim(
        win=win,
        name='image14_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_014.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-13.0)
    image15_HTRF_OD = visual.ImageStim(
        win=win,
        name='image15_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_015.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-14.0)
    image16_HTRF_OD = visual.ImageStim(
        win=win,
        name='image16_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_016.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-15.0)
    image17_HTRF_OD = visual.ImageStim(
        win=win,
        name='image17_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_017.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-16.0)
    image18_HTRF_OD = visual.ImageStim(
        win=win,
        name='image18_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_018.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-17.0)
    image19_HTRF_OD = visual.ImageStim(
        win=win,
        name='image19_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_019.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-18.0)
    image20_HTRF_OD = visual.ImageStim(
        win=win,
        name='image20_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_020.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-19.0)
    image21_HTRF_OD = visual.ImageStim(
        win=win,
        name='image21_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_021.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-20.0)
    image22_HTRF_OD = visual.ImageStim(
        win=win,
        name='image22_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_022.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-21.0)
    image23_HTRF_OD = visual.ImageStim(
        win=win,
        name='image23_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_023.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-22.0)
    image24_HTRF_OD = visual.ImageStim(
        win=win,
        name='image24_HTRF_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_024.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-23.0)
    image_Frame_HTRF_OD = visual.ImageStim(
        win=win,
        name='image_Frame_HTRF_OD', units='norm', 
        image='images/light_blue_frame_overlay.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2, 2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-24.0)
    image_Cue_HTRF_OD = visual.ImageStim(
        win=win,
        name='image_Cue_HTRF_OD', 
        image='images/ArrowRight.png', mask=None, anchor='center',
        ori=0.0, pos=(0.002, 0.0015), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-25.0)
    image_Cross_HTRF_OD = visual.ImageStim(
        win=win,
        name='image_Cross_HTRF_OD', 
        image='images/Cross.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-26.0)
    image_Tar_HTRF_OD = visual.ImageStim(
        win=win,
        name='image_Tar_HTRF_OD', 
        image='images/Target.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=(0.1, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=True, flipVert=False,
        texRes=128.0, interpolate=True, depth=-27.0)
    key_HTRF_OD = keyboard.Keyboard(deviceName='key_HTRF_OD')
    
    # --- Initialize components for Routine "Break" ---
    image_Frame_Break = visual.ImageStim(
        win=win,
        name='image_Frame_Break', units='norm', 
        image='images/light_blue_frame_overlay.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2, 2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_Cross_Break = visual.ImageStim(
        win=win,
        name='image_Cross_Break', 
        image='images/Cross.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # --- Initialize components for Routine "HTRU_OD" ---
    image1_HTRU_OD = visual.ImageStim(
        win=win,
        name='image1_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_001.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image2_HTRU_OD = visual.ImageStim(
        win=win,
        name='image2_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_002.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    image3_HTRU_OD = visual.ImageStim(
        win=win,
        name='image3_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_003.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-2.0)
    image4_HTRU_OD = visual.ImageStim(
        win=win,
        name='image4_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_004.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-3.0)
    image5_HTRU_OD = visual.ImageStim(
        win=win,
        name='image5_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_005.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-4.0)
    image6_HTRU_OD = visual.ImageStim(
        win=win,
        name='image6_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_006.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-5.0)
    image7_HTRU_OD = visual.ImageStim(
        win=win,
        name='image7_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_007.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-6.0)
    image8_HTRU_OD = visual.ImageStim(
        win=win,
        name='image8_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_008.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-7.0)
    image9_HTRU_OD = visual.ImageStim(
        win=win,
        name='image9_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_009.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-8.0)
    image10_HTRU_OD = visual.ImageStim(
        win=win,
        name='image10_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_010.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-9.0)
    image11_HTRU_OD = visual.ImageStim(
        win=win,
        name='image11_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_011.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-10.0)
    image12_HTRU_OD = visual.ImageStim(
        win=win,
        name='image12_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_012.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-11.0)
    image13_HTRU_OD = visual.ImageStim(
        win=win,
        name='image13_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_013.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-12.0)
    image14_HTRU_OD = visual.ImageStim(
        win=win,
        name='image14_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_014.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-13.0)
    image15_HTRU_OD = visual.ImageStim(
        win=win,
        name='image15_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_015.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-14.0)
    image16_HTRU_OD = visual.ImageStim(
        win=win,
        name='image16_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_016.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-15.0)
    image17_HTRU_OD = visual.ImageStim(
        win=win,
        name='image17_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_017.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-16.0)
    image18_HTRU_OD = visual.ImageStim(
        win=win,
        name='image18_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_018.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-17.0)
    image19_HTRU_OD = visual.ImageStim(
        win=win,
        name='image19_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_019.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-18.0)
    image20_HTRU_OD = visual.ImageStim(
        win=win,
        name='image20_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_020.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-19.0)
    image21_HTRU_OD = visual.ImageStim(
        win=win,
        name='image21_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_021.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-20.0)
    image22_HTRU_OD = visual.ImageStim(
        win=win,
        name='image22_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_022.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-21.0)
    image23_HTRU_OD = visual.ImageStim(
        win=win,
        name='image23_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_023.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-22.0)
    image24_HTRU_OD = visual.ImageStim(
        win=win,
        name='image24_HTRU_OD', units='norm', 
        image='images/pattern_images_rec_half_right/pattern_024.jpg', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2,2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-23.0)
    image_Frame_HTRU_OD = visual.ImageStim(
        win=win,
        name='image_Frame_HTRU_OD', units='norm', 
        image='images/light_blue_frame_overlay.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2, 2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-24.0)
    image_Cue_HTRU_OD = visual.ImageStim(
        win=win,
        name='image_Cue_HTRU_OD', 
        image='images/ArrowLeft.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-25.0)
    image_Cross_HTRU_OD = visual.ImageStim(
        win=win,
        name='image_Cross_HTRU_OD', 
        image='images/Cross.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-26.0)
    image_Tar_HTRU_OD = visual.ImageStim(
        win=win,
        name='image_Tar_HTRU_OD', 
        image='images/Target.png', mask=None, anchor='center',
        ori=0.0, pos=[0,0], draggable=False, size=(0.1, 0.1),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=True, flipVert=False,
        texRes=128.0, interpolate=True, depth=-27.0)
    key_HTRU_OD = keyboard.Keyboard(deviceName='key_HTRU_OD')
    
    # --- Initialize components for Routine "Break" ---
    image_Frame_Break = visual.ImageStim(
        win=win,
        name='image_Frame_Break', units='norm', 
        image='images/light_blue_frame_overlay.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(2, 2),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=0.0)
    image_Cross_Break = visual.ImageStim(
        win=win,
        name='image_Cross_Break', 
        image='images/Cross.png', mask=None, anchor='center',
        ori=0.0, pos=(0, 0), draggable=False, size=(0.08, 0.08),
        color=[1,1,1], colorSpace='rgb', opacity=None,
        flipHoriz=False, flipVert=False,
        texRes=128.0, interpolate=True, depth=-1.0)
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- CUSTOM: Start  --- 
    my_numtot = 9 # total number of stimuli in one block
    my_numval = 6 # number of valid stimuli in one block
    my_numinval = my_numtot - my_numval # number of invalid stimuli in one block
    my_outerloopnreps = 25 # number of repetitions of outerloop
    my_numcond = 4 # total number of conditions in paradigm
    my_totblocktime = 1.6
    
    print(expInfo['participant'])
    my_seq = open('shorter_sequences/CounterbalancedShorterSequence_'+str(expInfo['participant'])+'.txt', "r")
    my_seq_txt = my_seq.read()
    my_seq_num = np.zeros((my_outerloopnreps, 1))
    my_randtartime = np.random.randint(11,16,(my_numtot*my_outerloopnreps, 1))/10
    
    for i in range(my_outerloopnreps):
        my_seq_num[i] = int(my_seq_txt[2*i])
    
    my_rankTDA_L = np.zeros((my_numval, my_outerloopnreps))     # define array for ranks of valid stimuli in condition L
    my_rankTDA_R = np.zeros((my_numval, my_outerloopnreps))     # define array for ranks of valid stimuli in condition R
    my_rankTDA_GL = np.zeros((my_numval, my_outerloopnreps))    # define array for ranks of valid stimuli in condition GL
    my_rankTDA_GR = np.zeros((my_numval, my_outerloopnreps))    # define array for ranks of valid stimuli in condition GR
    
    my_corrResp_L = []     # define empty list for correct responses
    my_corrResp_R = []     # define empty list for correct responses
    my_corrResp_GL = []    # define empty list for correct responses
    my_corrResp_GR = []    # define empty list for correct responses
    
    for i in range(my_outerloopnreps): # loop over outerloops and choose ranks for stimuli in each iteration
        my_temp = np.random.permutation(my_numtot) # random permutation of numbers 0 to 9
        my_rankTDA_L[0:my_numval, i] = my_temp[0:my_numval] # choose ranks for valid stimuli 
        #my_rankTDA_L[0, i] = np.random.randint(low=0, high=10, size=None, dtype=int)
        #my_rankTDA_L[1, i] = np.random.randint(low=0, high=10, size=None, dtype=int)
        #while my_rankTDA_L[0, i] == my_rankTDA_L[1, i]:
            #my_rankTDA_L[1, i] = np.random.randint(low=0, high=8, size=None, dtype=int)

        my_temp = np.random.permutation(my_numtot) # random permutation of numbers 0 to 9
        my_rankTDA_R[0:my_numval, i] = my_temp[0:my_numval] # choose ranks for valid stimuli 
        #my_rankTDA_R[0, i] = np.random.randint(low=0, high=8, size=None, dtype=int)
        #my_rankTDA_R[1, i] = np.random.randint(low=0, high=8, size=None, dtype=int)
        #while my_rankTDA_R[0, i] == my_rankTDA_R[1, i]:
            #my_rankTDA_R[1, i] = np.random.randint(low=0, high=8, size=None, dtype=int)
        
        my_temp = np.random.permutation(my_numtot) # random permutation of numbers 0 to 9
        my_rankTDA_GL[0:my_numval, i] = my_temp[0:my_numval] # choose ranks for valid stimuli 
        #my_rankTDA_GL[0, i] = my_temp[0]
        #my_rankTDA_GL[1, i] = my_temp[1]
        #my_rankTDA_GL[2, i] = my_temp[2]
        #my_rankTDA_GL[3, i] = my_temp[3]
        #my_rankTDA_GL[4, i] = my_temp[4]
        
        my_temp = np.random.permutation(my_numtot) # random permutation of numbers 0 to 9
        my_rankTDA_GR[0:my_numval, i] = my_temp[0:my_numval] # choose ranks for valid stimuli 
        #my_rankTDA_GR[1, i] = my_temp[1]
        #my_rankTDA_GR[2, i] = my_temp[2]
        #my_rankTDA_GR[3, i] = my_temp[3]
        #my_rankTDA_GR[4, i] = my_temp[4]
    
    my_coordTDA_L = np.zeros((2, my_numtot, my_outerloopnreps))     # define array for coordinates of stimuli (1. Dimension: x,y; 2. Dim: stimuli of one block; 3. Dim: repetitions outerloop)
    my_coordTDA_R = np.zeros((2, my_numtot, my_outerloopnreps))     # define array for coordinates of stimuli
    my_coordTDA_GL = np.zeros((2, my_numtot, my_outerloopnreps))    # define array for coordinates of stimuli
    my_coordTDA_GR = np.zeros((2, my_numtot, my_outerloopnreps))    # define array for coordinates of stimuli
        
    for i in range(my_outerloopnreps): # loop over outerloops and fill arrays for coordinates and lists for correct responses
        my_corrResp_L.append([]) 
        my_corrResp_R.append([])
        my_corrResp_GL.append([])
        my_corrResp_GR.append([])
        
        for j in range(my_numtot):
            if (j in my_rankTDA_L[0:, i]):
                my_coordTDA_L[0,j,i] = np.random.rand()*0.2-0.4
                my_corrResp_L[i].append(1)
            else: 
                my_coordTDA_L[0,j,i] = 2.0
                my_corrResp_L[i].append(None)
            my_coordTDA_L[1, j, i] = np.random.rand()*0.8-0.4
            
            
            #if (j == my_rankTDA_L[0, i]) or (j == my_rankTDA_L[1, i]):
            #    my_coordTDA_L[0, j, i] = np.random.rand()*0.2-0.4
            #    my_corrResp_L[i].append(1)
            #else:
            #   my_coordTDA_L[0, j, i] = np.random.rand()*0.2+0.2
            #    my_corrResp_L[i].append(None)
            #my_coordTDA_L[1, j, i] = np.random.rand()*0.8-0.4

        
            if (j in my_rankTDA_R[0:, i]):
                my_coordTDA_R[0, j, i] = np.random.rand()*0.2+0.2
                my_corrResp_R[i].append(1)
            else:
                my_coordTDA_R[0, j, i] = 2.0
                my_corrResp_R[i].append(None)
            my_coordTDA_R[1, j, i] = np.random.rand()*0.8-0.4
            
            
            if (j in my_rankTDA_GL[0:, i]):
                my_coordTDA_GL[0, j, i] = np.random.rand()*0.2+0.2
                my_corrResp_GL[i].append(1)
            else:
                my_coordTDA_GL[0, j, i] = 2.0
                my_corrResp_GL[i].append(None)
            my_coordTDA_GL[1, j, i] = np.random.rand()*0.8-0.4
            
            if (j in my_rankTDA_GR[0:, i]):
                my_coordTDA_GR[0, j, i] = np.random.rand()*0.2-0.4
                my_corrResp_GR[i].append(1)
            else:
                my_coordTDA_GR[0, j, i] = 2.0
                my_corrResp_GR[i].append(None)
            my_coordTDA_GR[1, j, i] = np.random.rand()*0.8-0.4
            
    print("my_coordTDA_L")
    print(my_coordTDA_L)
    print("")
    print("my_coordTDA_R")
    print(my_coordTDA_R)
    print("")
    print("my_coordTDA_GL")
    print(my_coordTDA_GL)
    print("")
    print("my_coordTDA_GR")
    print(my_coordTDA_GR)
    print("")
    
    print("my_corrResp_L")
    print(my_corrResp_L)
    print("")
    print("my_corrResp_R")
    print(my_corrResp_R)
    print("")
    print("my_corrResp_GL")
    print(my_corrResp_GL)
    print("")
    print("my_corrResp_GR")
    print(my_corrResp_GR)
    print("")
    
    # --- CUSTOM: End  --- 
    
    # --- Prepare to start Routine "Trigger" ---
    # create an object to store info about Routine Trigger
    Trigger = data.Routine(
        name='Trigger',
        components=[],
    )
    Trigger.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # store start times for Trigger
    Trigger.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Trigger.tStart = globalClock.getTime(format='float')
    Trigger.status = STARTED
    thisExp.addData('Trigger.started', Trigger.tStart)
    Trigger.maxDuration = None
    # keep track of which components have finished
    TriggerComponents = Trigger.components
    for thisComponent in Trigger.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Trigger" ---
    Trigger.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer], 
                playbackComponents=[]
            )
            # skip the frame we paused on
            continue
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            Trigger.forceEnded = routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Trigger.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Trigger" ---
    for thisComponent in Trigger.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Trigger
    Trigger.tStop = globalClock.getTime(format='float')
    Trigger.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Trigger.stopped', Trigger.tStop)
    thisExp.nextEntry()
    # the Routine "Trigger" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    Outerloop = data.TrialHandler2(
        name='Outerloop',
        nReps=25.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=[None], 
        seed=None, 
    )
    thisExp.addLoop(Outerloop)  # add the loop to the experiment
    thisOuterloop = Outerloop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisOuterloop.rgb)
    if thisOuterloop != None:
        for paramName in thisOuterloop:
            globals()[paramName] = thisOuterloop[paramName]
    
    #--- CUSTOM START ---
    my_randtartime_counter = 0
    my_outerloopcounter = 0
    #--- CUSTOM END ---
    
    for thisOuterloop in Outerloop:
        currentLoop = Outerloop
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        # abbreviate parameter names if possible (e.g. rgb = thisOuterloop.rgb)
        if thisOuterloop != None:
            for paramName in thisOuterloop:
                globals()[paramName] = thisOuterloop[paramName]
        
        if my_seq_num[my_outerloopcounter]==1:
        #Custom-Comment: Start TDA_L
        
            # set up handler to look after randomisation of conditions etc
            TRials_HTLF_OD = data.TrialHandler2(
                name='TRials_HTLF_OD',
                nReps=1.0, 
                method='random', 
                extraInfo=expInfo, 
                originPath=-1, 
                trialList=data.importConditions('Conditions_TL_ND.xlsx'), 
                seed=None, 
            )
            thisExp.addLoop(TRials_HTLF_OD)  # add the loop to the experiment
            thisTRials_HTLF_OD = TRials_HTLF_OD.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTRials_HTLF_OD.rgb)
            if thisTRials_HTLF_OD != None:
                for paramName in thisTRials_HTLF_OD:
                    globals()[paramName] = thisTRials_HTLF_OD[paramName]
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            
            #--- CUSTOM START ---
            my_TDAL_counter = 0
            #--- CUSTOM END ---
            
            for thisTRials_HTLF_OD in TRials_HTLF_OD:
                currentLoop = TRials_HTLF_OD
                thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
                if thisSession is not None:
                    # if running in a Session with a Liaison client, send data up to now
                    thisSession.sendExperimentData()
                # abbreviate parameter names if possible (e.g. rgb = thisTRials_HTLF_OD.rgb)
                if thisTRials_HTLF_OD != None:
                    for paramName in thisTRials_HTLF_OD:
                        globals()[paramName] = thisTRials_HTLF_OD[paramName]
                
                # --- Prepare to start Routine "HTLF_OD" ---
                # create an object to store info about Routine HTLF_OD
                HTLF_OD = data.Routine(
                    name='HTLF_OD',
                    components=[image1_HTLF_OD, image2_HTLF_OD, image3_HTLF_OD, image4_HTLF_OD, image5_HTLF_OD, image6_HTLF_OD, image7_HTLF_OD, image8_HTLF_OD, image9_HTLF_OD, image10_HTLF_OD, image11_HTLF_OD, image12_HTLF_OD, image13_HTLF_OD, image14_HTLF_OD, image15_HTLF_OD, image16_HTLF_OD, image17_HTLF_OD, image18_HTLF_OD, image19_HTLF_OD, image20_HTLF_OD, image21_HTLF_OD, image22_HTLF_OD, image23_HTLF_OD, image24_HTLF_OD, image_Frame_HTLF_OD, image_Cue_HTLF_OD, image_Cross_HTLF_OD, image_Tar_HTLF_OD, key_HTLF_OD],
                )
                HTLF_OD.status = NOT_STARTED
                continueRoutine = True
                # update component parameters for each repeat
                #--- CUSTOM START ---
                image_Tar_HTLF_OD.setPos((my_coordTDA_L[0, my_TDAL_counter, my_outerloopcounter], my_coordTDA_L[1, my_TDAL_counter, my_outerloopcounter]))
                # replaces the old line 'image_Tar_HTLF.setPos((target_xcoor, target_ycoor))'
                #--- CUSTOM END ---
                # create starting attributes for key_HTLF_OD
                key_HTLF_OD.keys = []
                key_HTLF_OD.rt = []
                _key_HTLF_OD_allKeys = []
                # store start times for HTLF_OD
                HTLF_OD.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
                HTLF_OD.tStart = globalClock.getTime(format='float')
                HTLF_OD.status = STARTED
                thisExp.addData('HTLF_OD.started', HTLF_OD.tStart)
                HTLF_OD.maxDuration = None
                # keep track of which components have finished
                HTLF_ODComponents = HTLF_OD.components
                for thisComponent in HTLF_OD.components:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "HTLF_OD" ---
                # if trial has changed, end Routine now
                if isinstance(TRials_HTLF_OD, data.TrialHandler2) and thisTRials_HTLF_OD.thisN != TRials_HTLF_OD.thisTrial.thisN:
                    continueRoutine = False
                HTLF_OD.forceEnded = routineForceEnded = not continueRoutine
                while continueRoutine and routineTimer.getTime() < 1.6:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *image1_HTLF_OD* updates
                    
                    # if image1_HTLF_OD is starting this frame...
                    if image1_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image1_HTLF_OD.frameNStart = frameN  # exact frame index
                        image1_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image1_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image1_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image1_HTLF_OD.started')
                        # update status
                        image1_HTLF_OD.status = STARTED
                        image1_HTLF_OD.setAutoDraw(True)
                    
                    # if image1_HTLF_OD is active this frame...
                    if image1_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image1_HTLF_OD is stopping this frame...
                    if image1_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image1_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image1_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image1_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image1_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image1_HTLF_OD.stopped')
                            # update status
                            image1_HTLF_OD.status = FINISHED
                            image1_HTLF_OD.setAutoDraw(False)
                    
                    # *image2_HTLF_OD* updates
                    
                    # if image2_HTLF_OD is starting this frame...
                    if image2_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.066667-frameTolerance:
                        # keep track of start time/frame for later
                        image2_HTLF_OD.frameNStart = frameN  # exact frame index
                        image2_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image2_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image2_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image2_HTLF_OD.started')
                        # update status
                        image2_HTLF_OD.status = STARTED
                        image2_HTLF_OD.setAutoDraw(True)
                    
                    # if image2_HTLF_OD is active this frame...
                    if image2_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image2_HTLF_OD is stopping this frame...
                    if image2_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image2_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image2_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image2_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image2_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image2_HTLF_OD.stopped')
                            # update status
                            image2_HTLF_OD.status = FINISHED
                            image2_HTLF_OD.setAutoDraw(False)
                    
                    # *image3_HTLF_OD* updates
                    
                    # if image3_HTLF_OD is starting this frame...
                    if image3_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.133334-frameTolerance:
                        # keep track of start time/frame for later
                        image3_HTLF_OD.frameNStart = frameN  # exact frame index
                        image3_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image3_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image3_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image3_HTLF_OD.started')
                        # update status
                        image3_HTLF_OD.status = STARTED
                        image3_HTLF_OD.setAutoDraw(True)
                    
                    # if image3_HTLF_OD is active this frame...
                    if image3_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image3_HTLF_OD is stopping this frame...
                    if image3_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image3_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image3_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image3_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image3_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image3_HTLF_OD.stopped')
                            # update status
                            image3_HTLF_OD.status = FINISHED
                            image3_HTLF_OD.setAutoDraw(False)
                    
                    # *image4_HTLF_OD* updates
                    
                    # if image4_HTLF_OD is starting this frame...
                    if image4_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.200001-frameTolerance:
                        # keep track of start time/frame for later
                        image4_HTLF_OD.frameNStart = frameN  # exact frame index
                        image4_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image4_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image4_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image4_HTLF_OD.started')
                        # update status
                        image4_HTLF_OD.status = STARTED
                        image4_HTLF_OD.setAutoDraw(True)
                    
                    # if image4_HTLF_OD is active this frame...
                    if image4_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image4_HTLF_OD is stopping this frame...
                    if image4_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image4_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image4_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image4_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image4_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image4_HTLF_OD.stopped')
                            # update status
                            image4_HTLF_OD.status = FINISHED
                            image4_HTLF_OD.setAutoDraw(False)
                    
                    # *image5_HTLF_OD* updates
                    
                    # if image5_HTLF_OD is starting this frame...
                    if image5_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.266668-frameTolerance:
                        # keep track of start time/frame for later
                        image5_HTLF_OD.frameNStart = frameN  # exact frame index
                        image5_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image5_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image5_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image5_HTLF_OD.started')
                        # update status
                        image5_HTLF_OD.status = STARTED
                        image5_HTLF_OD.setAutoDraw(True)
                    
                    # if image5_HTLF_OD is active this frame...
                    if image5_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image5_HTLF_OD is stopping this frame...
                    if image5_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image5_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image5_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image5_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image5_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image5_HTLF_OD.stopped')
                            # update status
                            image5_HTLF_OD.status = FINISHED
                            image5_HTLF_OD.setAutoDraw(False)
                    
                    # *image6_HTLF_OD* updates
                    
                    # if image6_HTLF_OD is starting this frame...
                    if image6_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.333335-frameTolerance:
                        # keep track of start time/frame for later
                        image6_HTLF_OD.frameNStart = frameN  # exact frame index
                        image6_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image6_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image6_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image6_HTLF_OD.started')
                        # update status
                        image6_HTLF_OD.status = STARTED
                        image6_HTLF_OD.setAutoDraw(True)
                    
                    # if image6_HTLF_OD is active this frame...
                    if image6_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image6_HTLF_OD is stopping this frame...
                    if image6_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image6_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image6_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image6_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image6_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image6_HTLF_OD.stopped')
                            # update status
                            image6_HTLF_OD.status = FINISHED
                            image6_HTLF_OD.setAutoDraw(False)
                    
                    # *image7_HTLF_OD* updates
                    
                    # if image7_HTLF_OD is starting this frame...
                    if image7_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.400002-frameTolerance:
                        # keep track of start time/frame for later
                        image7_HTLF_OD.frameNStart = frameN  # exact frame index
                        image7_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image7_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image7_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image7_HTLF_OD.started')
                        # update status
                        image7_HTLF_OD.status = STARTED
                        image7_HTLF_OD.setAutoDraw(True)
                    
                    # if image7_HTLF_OD is active this frame...
                    if image7_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image7_HTLF_OD is stopping this frame...
                    if image7_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image7_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image7_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image7_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image7_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image7_HTLF_OD.stopped')
                            # update status
                            image7_HTLF_OD.status = FINISHED
                            image7_HTLF_OD.setAutoDraw(False)
                    
                    # *image8_HTLF_OD* updates
                    
                    # if image8_HTLF_OD is starting this frame...
                    if image8_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.466669-frameTolerance:
                        # keep track of start time/frame for later
                        image8_HTLF_OD.frameNStart = frameN  # exact frame index
                        image8_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image8_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image8_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image8_HTLF_OD.started')
                        # update status
                        image8_HTLF_OD.status = STARTED
                        image8_HTLF_OD.setAutoDraw(True)
                    
                    # if image8_HTLF_OD is active this frame...
                    if image8_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image8_HTLF_OD is stopping this frame...
                    if image8_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image8_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image8_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image8_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image8_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image8_HTLF_OD.stopped')
                            # update status
                            image8_HTLF_OD.status = FINISHED
                            image8_HTLF_OD.setAutoDraw(False)
                    
                    # *image9_HTLF_OD* updates
                    
                    # if image9_HTLF_OD is starting this frame...
                    if image9_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.533336-frameTolerance:
                        # keep track of start time/frame for later
                        image9_HTLF_OD.frameNStart = frameN  # exact frame index
                        image9_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image9_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image9_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image9_HTLF_OD.started')
                        # update status
                        image9_HTLF_OD.status = STARTED
                        image9_HTLF_OD.setAutoDraw(True)
                    
                    # if image9_HTLF_OD is active this frame...
                    if image9_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image9_HTLF_OD is stopping this frame...
                    if image9_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image9_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image9_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image9_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image9_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image9_HTLF_OD.stopped')
                            # update status
                            image9_HTLF_OD.status = FINISHED
                            image9_HTLF_OD.setAutoDraw(False)
                    
                    # *image10_HTLF_OD* updates
                    
                    # if image10_HTLF_OD is starting this frame...
                    if image10_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.600003-frameTolerance:
                        # keep track of start time/frame for later
                        image10_HTLF_OD.frameNStart = frameN  # exact frame index
                        image10_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image10_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image10_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image10_HTLF_OD.started')
                        # update status
                        image10_HTLF_OD.status = STARTED
                        image10_HTLF_OD.setAutoDraw(True)
                    
                    # if image10_HTLF_OD is active this frame...
                    if image10_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image10_HTLF_OD is stopping this frame...
                    if image10_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image10_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image10_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image10_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image10_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image10_HTLF_OD.stopped')
                            # update status
                            image10_HTLF_OD.status = FINISHED
                            image10_HTLF_OD.setAutoDraw(False)
                    
                    # *image11_HTLF_OD* updates
                    
                    # if image11_HTLF_OD is starting this frame...
                    if image11_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.666670-frameTolerance:
                        # keep track of start time/frame for later
                        image11_HTLF_OD.frameNStart = frameN  # exact frame index
                        image11_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image11_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image11_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image11_HTLF_OD.started')
                        # update status
                        image11_HTLF_OD.status = STARTED
                        image11_HTLF_OD.setAutoDraw(True)
                    
                    # if image11_HTLF_OD is active this frame...
                    if image11_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image11_HTLF_OD is stopping this frame...
                    if image11_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image11_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image11_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image11_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image11_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image11_HTLF_OD.stopped')
                            # update status
                            image11_HTLF_OD.status = FINISHED
                            image11_HTLF_OD.setAutoDraw(False)
                    
                    # *image12_HTLF_OD* updates
                    
                    # if image12_HTLF_OD is starting this frame...
                    if image12_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.733337-frameTolerance:
                        # keep track of start time/frame for later
                        image12_HTLF_OD.frameNStart = frameN  # exact frame index
                        image12_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image12_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image12_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image12_HTLF_OD.started')
                        # update status
                        image12_HTLF_OD.status = STARTED
                        image12_HTLF_OD.setAutoDraw(True)
                    
                    # if image12_HTLF_OD is active this frame...
                    if image12_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image12_HTLF_OD is stopping this frame...
                    if image12_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image12_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image12_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image12_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image12_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image12_HTLF_OD.stopped')
                            # update status
                            image12_HTLF_OD.status = FINISHED
                            image12_HTLF_OD.setAutoDraw(False)
                    
                    # *image13_HTLF_OD* updates
                    
                    # if image13_HTLF_OD is starting this frame...
                    if image13_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.800004-frameTolerance:
                        # keep track of start time/frame for later
                        image13_HTLF_OD.frameNStart = frameN  # exact frame index
                        image13_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image13_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image13_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image13_HTLF_OD.started')
                        # update status
                        image13_HTLF_OD.status = STARTED
                        image13_HTLF_OD.setAutoDraw(True)
                    
                    # if image13_HTLF_OD is active this frame...
                    if image13_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image13_HTLF_OD is stopping this frame...
                    if image13_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image13_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image13_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image13_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image13_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image13_HTLF_OD.stopped')
                            # update status
                            image13_HTLF_OD.status = FINISHED
                            image13_HTLF_OD.setAutoDraw(False)
                    
                    # *image14_HTLF_OD* updates
                    
                    # if image14_HTLF_OD is starting this frame...
                    if image14_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.866671-frameTolerance:
                        # keep track of start time/frame for later
                        image14_HTLF_OD.frameNStart = frameN  # exact frame index
                        image14_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image14_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image14_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image14_HTLF_OD.started')
                        # update status
                        image14_HTLF_OD.status = STARTED
                        image14_HTLF_OD.setAutoDraw(True)
                    
                    # if image14_HTLF_OD is active this frame...
                    if image14_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image14_HTLF_OD is stopping this frame...
                    if image14_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image14_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image14_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image14_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image14_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image14_HTLF_OD.stopped')
                            # update status
                            image14_HTLF_OD.status = FINISHED
                            image14_HTLF_OD.setAutoDraw(False)
                    
                    # *image15_HTLF_OD* updates
                    
                    # if image15_HTLF_OD is starting this frame...
                    if image15_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.933338-frameTolerance:
                        # keep track of start time/frame for later
                        image15_HTLF_OD.frameNStart = frameN  # exact frame index
                        image15_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image15_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image15_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image15_HTLF_OD.started')
                        # update status
                        image15_HTLF_OD.status = STARTED
                        image15_HTLF_OD.setAutoDraw(True)
                    
                    # if image15_HTLF_OD is active this frame...
                    if image15_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image15_HTLF_OD is stopping this frame...
                    if image15_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image15_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image15_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image15_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image15_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image15_HTLF_OD.stopped')
                            # update status
                            image15_HTLF_OD.status = FINISHED
                            image15_HTLF_OD.setAutoDraw(False)
                    
                    # *image16_HTLF_OD* updates
                    
                    # if image16_HTLF_OD is starting this frame...
                    if image16_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.000005-frameTolerance:
                        # keep track of start time/frame for later
                        image16_HTLF_OD.frameNStart = frameN  # exact frame index
                        image16_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image16_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image16_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image16_HTLF_OD.started')
                        # update status
                        image16_HTLF_OD.status = STARTED
                        image16_HTLF_OD.setAutoDraw(True)
                    
                    # if image16_HTLF_OD is active this frame...
                    if image16_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image16_HTLF_OD is stopping this frame...
                    if image16_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image16_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image16_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image16_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image16_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image16_HTLF_OD.stopped')
                            # update status
                            image16_HTLF_OD.status = FINISHED
                            image16_HTLF_OD.setAutoDraw(False)
                    
                    # *image17_HTLF_OD* updates
                    
                    # if image17_HTLF_OD is starting this frame...
                    if image17_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.066672-frameTolerance:
                        # keep track of start time/frame for later
                        image17_HTLF_OD.frameNStart = frameN  # exact frame index
                        image17_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image17_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image17_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image17_HTLF_OD.started')
                        # update status
                        image17_HTLF_OD.status = STARTED
                        image17_HTLF_OD.setAutoDraw(True)
                    
                    # if image17_HTLF_OD is active this frame...
                    if image17_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image17_HTLF_OD is stopping this frame...
                    if image17_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image17_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image17_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image17_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image17_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image17_HTLF_OD.stopped')
                            # update status
                            image17_HTLF_OD.status = FINISHED
                            image17_HTLF_OD.setAutoDraw(False)
                    
                    # *image18_HTLF_OD* updates
                    
                    # if image18_HTLF_OD is starting this frame...
                    if image18_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.133339-frameTolerance:
                        # keep track of start time/frame for later
                        image18_HTLF_OD.frameNStart = frameN  # exact frame index
                        image18_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image18_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image18_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image18_HTLF_OD.started')
                        # update status
                        image18_HTLF_OD.status = STARTED
                        image18_HTLF_OD.setAutoDraw(True)
                    
                    # if image18_HTLF_OD is active this frame...
                    if image18_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image18_HTLF_OD is stopping this frame...
                    if image18_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image18_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image18_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image18_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image18_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image18_HTLF_OD.stopped')
                            # update status
                            image18_HTLF_OD.status = FINISHED
                            image18_HTLF_OD.setAutoDraw(False)
                    
                    # *image19_HTLF_OD* updates
                    
                    # if image19_HTLF_OD is starting this frame...
                    if image19_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.200006-frameTolerance:
                        # keep track of start time/frame for later
                        image19_HTLF_OD.frameNStart = frameN  # exact frame index
                        image19_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image19_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image19_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image19_HTLF_OD.started')
                        # update status
                        image19_HTLF_OD.status = STARTED
                        image19_HTLF_OD.setAutoDraw(True)
                    
                    # if image19_HTLF_OD is active this frame...
                    if image19_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image19_HTLF_OD is stopping this frame...
                    if image19_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image19_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image19_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image19_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image19_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image19_HTLF_OD.stopped')
                            # update status
                            image19_HTLF_OD.status = FINISHED
                            image19_HTLF_OD.setAutoDraw(False)
                    
                    # *image20_HTLF_OD* updates
                    
                    # if image20_HTLF_OD is starting this frame...
                    if image20_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.266673-frameTolerance:
                        # keep track of start time/frame for later
                        image20_HTLF_OD.frameNStart = frameN  # exact frame index
                        image20_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image20_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image20_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image20_HTLF_OD.started')
                        # update status
                        image20_HTLF_OD.status = STARTED
                        image20_HTLF_OD.setAutoDraw(True)
                    
                    # if image20_HTLF_OD is active this frame...
                    if image20_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image20_HTLF_OD is stopping this frame...
                    if image20_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image20_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image20_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image20_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image20_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image20_HTLF_OD.stopped')
                            # update status
                            image20_HTLF_OD.status = FINISHED
                            image20_HTLF_OD.setAutoDraw(False)
                    
                    # *image21_HTLF_OD* updates
                    
                    # if image21_HTLF_OD is starting this frame...
                    if image21_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.333340-frameTolerance:
                        # keep track of start time/frame for later
                        image21_HTLF_OD.frameNStart = frameN  # exact frame index
                        image21_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image21_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image21_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image21_HTLF_OD.started')
                        # update status
                        image21_HTLF_OD.status = STARTED
                        image21_HTLF_OD.setAutoDraw(True)
                    
                    # if image21_HTLF_OD is active this frame...
                    if image21_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image21_HTLF_OD is stopping this frame...
                    if image21_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image21_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image21_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image21_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image21_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image21_HTLF_OD.stopped')
                            # update status
                            image21_HTLF_OD.status = FINISHED
                            image21_HTLF_OD.setAutoDraw(False)
                    
                    # *image22_HTLF_OD* updates
                    
                    # if image22_HTLF_OD is starting this frame...
                    if image22_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.400007-frameTolerance:
                        # keep track of start time/frame for later
                        image22_HTLF_OD.frameNStart = frameN  # exact frame index
                        image22_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image22_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image22_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image22_HTLF_OD.started')
                        # update status
                        image22_HTLF_OD.status = STARTED
                        image22_HTLF_OD.setAutoDraw(True)
                    
                    # if image22_HTLF_OD is active this frame...
                    if image22_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image22_HTLF_OD is stopping this frame...
                    if image22_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image22_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image22_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image22_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image22_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image22_HTLF_OD.stopped')
                            # update status
                            image22_HTLF_OD.status = FINISHED
                            image22_HTLF_OD.setAutoDraw(False)
                    
                    # *image23_HTLF_OD* updates
                    
                    # if image23_HTLF_OD is starting this frame...
                    if image23_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.466674-frameTolerance:
                        # keep track of start time/frame for later
                        image23_HTLF_OD.frameNStart = frameN  # exact frame index
                        image23_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image23_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image23_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image23_HTLF_OD.started')
                        # update status
                        image23_HTLF_OD.status = STARTED
                        image23_HTLF_OD.setAutoDraw(True)
                    
                    # if image23_HTLF_OD is active this frame...
                    if image23_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image23_HTLF_OD is stopping this frame...
                    if image23_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image23_HTLF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image23_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image23_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image23_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image23_HTLF_OD.stopped')
                            # update status
                            image23_HTLF_OD.status = FINISHED
                            image23_HTLF_OD.setAutoDraw(False)
                    
                    # *image24_HTLF_OD* updates
                    
                    # if image24_HTLF_OD is starting this frame...
                    if image24_HTLF_OD.status == NOT_STARTED and tThisFlip >= 1.533341-frameTolerance:
                        # keep track of start time/frame for later
                        image24_HTLF_OD.frameNStart = frameN  # exact frame index
                        image24_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image24_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image24_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image24_HTLF_OD.started')
                        # update status
                        image24_HTLF_OD.status = STARTED
                        image24_HTLF_OD.setAutoDraw(True)
                    
                    # if image24_HTLF_OD is active this frame...
                    if image24_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image24_HTLF_OD is stopping this frame...
                    if image24_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image24_HTLF_OD.tStartRefresh + 0.066659-frameTolerance:
                            # keep track of stop time/frame for later
                            image24_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image24_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image24_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image24_HTLF_OD.stopped')
                            # update status
                            image24_HTLF_OD.status = FINISHED
                            image24_HTLF_OD.setAutoDraw(False)
                    
                    # *image_Frame_HTLF_OD* updates
                    
                    # if image_Frame_HTLF_OD is starting this frame...
                    if image_Frame_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Frame_HTLF_OD.frameNStart = frameN  # exact frame index
                        image_Frame_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image_Frame_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Frame_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Frame_HTLF_OD.started')
                        # update status
                        image_Frame_HTLF_OD.status = STARTED
                        image_Frame_HTLF_OD.setAutoDraw(True)
                    
                    # if image_Frame_HTLF_OD is active this frame...
                    if image_Frame_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Frame_HTLF_OD is stopping this frame...
                    if image_Frame_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Frame_HTLF_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Frame_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image_Frame_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Frame_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Frame_HTLF_OD.stopped')
                            # update status
                            image_Frame_HTLF_OD.status = FINISHED
                            image_Frame_HTLF_OD.setAutoDraw(False)
                    
                    # *image_Cue_HTLF_OD* updates
                    
                    # if image_Cue_HTLF_OD is starting this frame...
                    if image_Cue_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Cue_HTLF_OD.frameNStart = frameN  # exact frame index
                        image_Cue_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image_Cue_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Cue_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cue_HTLF_OD.started')
                        # update status
                        image_Cue_HTLF_OD.status = STARTED
                        image_Cue_HTLF_OD.setAutoDraw(True)
                    
                    # if image_Cue_HTLF_OD is active this frame...
                    if image_Cue_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Cue_HTLF_OD is stopping this frame...
                    if image_Cue_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Cue_HTLF_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Cue_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image_Cue_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Cue_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Cue_HTLF_OD.stopped')
                            # update status
                            image_Cue_HTLF_OD.status = FINISHED
                            image_Cue_HTLF_OD.setAutoDraw(False)
                    
                    # *image_Cross_HTLF_OD* updates
                    
                    # if image_Cross_HTLF_OD is starting this frame...
                    if image_Cross_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Cross_HTLF_OD.frameNStart = frameN  # exact frame index
                        image_Cross_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image_Cross_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Cross_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cross_HTLF_OD.started')
                        # update status
                        image_Cross_HTLF_OD.status = STARTED
                        image_Cross_HTLF_OD.setAutoDraw(True)
                    
                    # if image_Cross_HTLF_OD is active this frame...
                    if image_Cross_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Cross_HTLF_OD is stopping this frame...
                    if image_Cross_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Cross_HTLF_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Cross_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image_Cross_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Cross_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Cross_HTLF_OD.stopped')
                            # update status
                            image_Cross_HTLF_OD.status = FINISHED
                            image_Cross_HTLF_OD.setAutoDraw(False)
                    
                    # *image_Tar_HTLF_OD* updates
                    
                    # if image_Tar_HTLF_OD is starting this frame...
                    if image_Tar_HTLF_OD.status == NOT_STARTED and tThisFlip >= (1.6 - my_randtartime[my_randtartime_counter])-frameTolerance:   ### CUSTOM START AND END 
                        # keep track of start time/frame for later
                        image_Tar_HTLF_OD.frameNStart = frameN  # exact frame index
                        image_Tar_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        image_Tar_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Tar_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Tar_HTLF_OD.started')
                        # update status
                        image_Tar_HTLF_OD.status = STARTED
                        image_Tar_HTLF_OD.setAutoDraw(True)
                    
                    # if image_Tar_HTLF_OD is active this frame...
                    if image_Tar_HTLF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Tar_HTLF_OD is stopping this frame...
                    if image_Tar_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Tar_HTLF_OD.tStartRefresh + my_randtartime[my_randtartime_counter]-frameTolerance:         ### CUSTOM START AND END 
                            # keep track of stop time/frame for later
                            image_Tar_HTLF_OD.tStop = t  # not accounting for scr refresh
                            image_Tar_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Tar_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Tar_HTLF_OD.stopped')
                            # update status
                            image_Tar_HTLF_OD.status = FINISHED
                            image_Tar_HTLF_OD.setAutoDraw(False)
                    
                    # *key_HTLF_OD* updates
                    waitOnFlip = False
                    
                    # if key_HTLF_OD is starting this frame...
                    if key_HTLF_OD.status == NOT_STARTED and tThisFlip >= 0.1-frameTolerance:
                        # keep track of start time/frame for later
                        key_HTLF_OD.frameNStart = frameN  # exact frame index
                        key_HTLF_OD.tStart = t  # local t and not account for scr refresh
                        key_HTLF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(key_HTLF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'key_HTLF_OD.started')
                        # update status
                        key_HTLF_OD.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(key_HTLF_OD.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(key_HTLF_OD.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    
                    # if key_HTLF_OD is stopping this frame...
                    if key_HTLF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > key_HTLF_OD.tStartRefresh + 1.5-frameTolerance:
                            # keep track of stop time/frame for later
                            key_HTLF_OD.tStop = t  # not accounting for scr refresh
                            key_HTLF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            key_HTLF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'key_HTLF_OD.stopped')
                            # update status
                            key_HTLF_OD.status = FINISHED
                            key_HTLF_OD.status = FINISHED
                    if key_HTLF_OD.status == STARTED and not waitOnFlip:
                        theseKeys = key_HTLF_OD.getKeys(keyList=['1'], ignoreKeys=["escape"], waitRelease=False)
                        _key_HTLF_OD_allKeys.extend(theseKeys)
                        if len(_key_HTLF_OD_allKeys):
                            key_HTLF_OD.keys = _key_HTLF_OD_allKeys[0].name  # just the first key pressed
                            key_HTLF_OD.rt = _key_HTLF_OD_allKeys[0].rt
                            key_HTLF_OD.duration = _key_HTLF_OD_allKeys[0].duration
                            # was this correct?
                            #CUSTOM: Start
                            #if (key_HTLF.keys == str(corr_resp)) or (key_HTLF.keys == corr_resp):
                            if (key_HTLF_OD.keys == str(my_corrResp_L[my_outerloopcounter][my_TDAL_counter])) or (key_HTLF.keys == my_corrResp_L[my_outerloopcounter][my_TDAL_counter]):
                                key_HTLF_OD.corr = 1
                            else:
                                key_HTLF_OD.corr = 0
                            #CUSTOM: End
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, win=win)
                        return
                    # pause experiment here if requested
                    if thisExp.status == PAUSED:
                        pauseExperiment(
                            thisExp=thisExp, 
                            win=win, 
                            timers=[routineTimer], 
                            playbackComponents=[]
                        )
                        # skip the frame we paused on
                        continue
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        HTLF_OD.forceEnded = routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in HTLF_OD.components:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                my_randtartime_counter = my_randtartime_counter + 1          ### CUSTOM START AND END
                
                # --- Ending Routine "HTLF_OD" ---
                for thisComponent in HTLF_OD.components:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                # store stop times for HTLF_OD
                HTLF_OD.tStop = globalClock.getTime(format='float')
                HTLF_OD.tStopRefresh = tThisFlipGlobal
                thisExp.addData('HTLF_OD.stopped', HTLF_OD.tStop)
                # check responses
                if key_HTLF_OD.keys in ['', [], None]:  # No response was made
                    key_HTLF_OD.keys = None
                    # was no response the correct answer?!
                    if str(my_corrResp_L[my_outerloopcounter][my_TDAL_counter]).lower() == 'none': ## CUSTOM START & END
                       key_HTLF_OD.corr = 1;  # correct non-response
                    else:
                       key_HTLF_OD.corr = 0;  # failed to respond (incorrectly)
                # store data for TRials_HTLF_OD (TrialHandler)
                TRials_HTLF_OD.addData('key_HTLF_OD.keys',key_HTLF_OD.keys)
                TRials_HTLF_OD.addData('key_HTLF_OD.corr', key_HTLF_OD.corr)
                if key_HTLF_OD.keys != None:  # we had a response
                    TRials_HTLF_OD.addData('key_HTLF_OD.rt', key_HTLF_OD.rt)
                    TRials_HTLF_OD.addData('key_HTLF_OD.duration', key_HTLF_OD.duration)
                try:
                    if image1_HTLF_OD.tStopRefresh is not None:
                        duration_val = image1_HTLF_OD.tStopRefresh - image1_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image1_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image1_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image1_HTLF_OD).__name__,
                        trial_type='image1_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image1_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image2_HTLF_OD.tStopRefresh is not None:
                        duration_val = image2_HTLF_OD.tStopRefresh - image2_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image2_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image2_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image2_HTLF_OD).__name__,
                        trial_type='image2_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image2_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image3_HTLF_OD.tStopRefresh is not None:
                        duration_val = image3_HTLF_OD.tStopRefresh - image3_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image3_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image3_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image3_HTLF_OD).__name__,
                        trial_type='image3_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image3_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image4_HTLF_OD.tStopRefresh is not None:
                        duration_val = image4_HTLF_OD.tStopRefresh - image4_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image4_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image4_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image4_HTLF_OD).__name__,
                        trial_type='image4_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image4_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image5_HTLF_OD.tStopRefresh is not None:
                        duration_val = image5_HTLF_OD.tStopRefresh - image5_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image5_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image5_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image5_HTLF_OD).__name__,
                        trial_type='image5_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image5_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image6_HTLF_OD.tStopRefresh is not None:
                        duration_val = image6_HTLF_OD.tStopRefresh - image6_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image6_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image6_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image6_HTLF_OD).__name__,
                        trial_type='image6_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image6_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image7_HTLF_OD.tStopRefresh is not None:
                        duration_val = image7_HTLF_OD.tStopRefresh - image7_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image7_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image7_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image7_HTLF_OD).__name__,
                        trial_type='image7_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image7_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image8_HTLF_OD.tStopRefresh is not None:
                        duration_val = image8_HTLF_OD.tStopRefresh - image8_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image8_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image8_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image8_HTLF_OD).__name__,
                        trial_type='image8_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image8_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image9_HTLF_OD.tStopRefresh is not None:
                        duration_val = image9_HTLF_OD.tStopRefresh - image9_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image9_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image9_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image9_HTLF_OD).__name__,
                        trial_type='image9_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image9_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image10_HTLF_OD.tStopRefresh is not None:
                        duration_val = image10_HTLF_OD.tStopRefresh - image10_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image10_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image10_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image10_HTLF_OD).__name__,
                        trial_type='image10_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image10_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image11_HTLF_OD.tStopRefresh is not None:
                        duration_val = image11_HTLF_OD.tStopRefresh - image11_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image11_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image11_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image11_HTLF_OD).__name__,
                        trial_type='image11_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image11_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image12_HTLF_OD.tStopRefresh is not None:
                        duration_val = image12_HTLF_OD.tStopRefresh - image12_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image12_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image12_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image12_HTLF_OD).__name__,
                        trial_type='image12_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image12_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image13_HTLF_OD.tStopRefresh is not None:
                        duration_val = image13_HTLF_OD.tStopRefresh - image13_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image13_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image13_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image13_HTLF_OD).__name__,
                        trial_type='image13_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image13_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image14_HTLF_OD.tStopRefresh is not None:
                        duration_val = image14_HTLF_OD.tStopRefresh - image14_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image14_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image14_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image14_HTLF_OD).__name__,
                        trial_type='image14_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image14_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image15_HTLF_OD.tStopRefresh is not None:
                        duration_val = image15_HTLF_OD.tStopRefresh - image15_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image15_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image15_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image15_HTLF_OD).__name__,
                        trial_type='image15_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image15_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image16_HTLF_OD.tStopRefresh is not None:
                        duration_val = image16_HTLF_OD.tStopRefresh - image16_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image16_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image16_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image16_HTLF_OD).__name__,
                        trial_type='image16_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image16_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image17_HTLF_OD.tStopRefresh is not None:
                        duration_val = image17_HTLF_OD.tStopRefresh - image17_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image17_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image17_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image17_HTLF_OD).__name__,
                        trial_type='image17_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image17_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image18_HTLF_OD.tStopRefresh is not None:
                        duration_val = image18_HTLF_OD.tStopRefresh - image18_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image18_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image18_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image18_HTLF_OD).__name__,
                        trial_type='image18_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image18_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image19_HTLF_OD.tStopRefresh is not None:
                        duration_val = image19_HTLF_OD.tStopRefresh - image19_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image19_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image19_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image19_HTLF_OD).__name__,
                        trial_type='image19_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image19_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image20_HTLF_OD.tStopRefresh is not None:
                        duration_val = image20_HTLF_OD.tStopRefresh - image20_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image20_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image20_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image20_HTLF_OD).__name__,
                        trial_type='image20_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image20_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image21_HTLF_OD.tStopRefresh is not None:
                        duration_val = image21_HTLF_OD.tStopRefresh - image21_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image21_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image21_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image21_HTLF_OD).__name__,
                        trial_type='image21_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image21_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image22_HTLF_OD.tStopRefresh is not None:
                        duration_val = image22_HTLF_OD.tStopRefresh - image22_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image22_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image22_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image22_HTLF_OD).__name__,
                        trial_type='image22_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image22_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image23_HTLF_OD.tStopRefresh is not None:
                        duration_val = image23_HTLF_OD.tStopRefresh - image23_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image23_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image23_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image23_HTLF_OD).__name__,
                        trial_type='image23_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image23_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image24_HTLF_OD.tStopRefresh is not None:
                        duration_val = image24_HTLF_OD.tStopRefresh - image24_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image24_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image24_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image24_HTLF_OD).__name__,
                        trial_type='image24_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image24_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image_Cue_HTLF_OD.tStopRefresh is not None:
                        duration_val = image_Cue_HTLF_OD.tStopRefresh - image_Cue_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image_Cue_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image_Cue_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image_Cue_HTLF_OD).__name__,
                        trial_type='image_Cue_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image_Cue_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image_Tar_HTLF_OD.tStopRefresh is not None:
                        duration_val = image_Tar_HTLF_OD.tStopRefresh - image_Tar_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - image_Tar_HTLF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image_Tar_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image_Tar_HTLF_OD).__name__,
                        trial_type='image_Tar_HTLF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_image_Tar_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if key_HTLF_OD.tStopRefresh is not None:
                        duration_val = key_HTLF_OD.tStopRefresh - key_HTLF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLF_OD.stopped'] - key_HTLF_OD.tStartRefresh
                    if hasattr(key_HTLF_OD, 'rt'):
                        rt_val = key_HTLF_OD.rt
                    else:
                        rt_val = None
                        logging.warning('The linked component "key_HTLF_OD" does not have a reaction time(.rt) attribute. Unable to link BIDS response_time to this component. Please verify the component settings.')
                    bids_event = BIDSTaskEvent(
                        onset=key_HTLF_OD.tStartRefresh,
                        duration=duration_val,
                        response_time=rt_val,
                        event_type=type(key_HTLF_OD).__name__,
                        trial_type='key_HTLF_OD',
                        value=key_HTLF_OD.corr,
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        TRials_HTLF_OD.addData('bidsEvent_key_HTLF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
                if HTLF_OD.maxDurationReached:
                    routineTimer.addTime(-HTLF_OD.maxDuration)
                elif HTLF_OD.forceEnded:
                    routineTimer.reset()
                else:
                    routineTimer.addTime(-1.600000)
                thisExp.nextEntry()
                
                #--- CUSTOM START ---
                my_TDAL_counter = my_TDAL_counter + 1
                #--- CUSTOM END ---
                
            # completed 1.0 repeats of 'TRials_HTLF_OD'
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            # get names of stimulus parameters
            if TRials_HTLF_OD.trialList in ([], [None], None):
                params = []
            else:
                params = TRials_HTLF_OD.trialList[0].keys()
            # save data for this loop
            TRials_HTLF_OD.saveAsExcel(filename + '.xlsx', sheetName='TRials_HTLF_OD',
                stimOut=params,
                dataOut=['n','all_mean','all_std', 'all_raw'])
            TRials_HTLF_OD.saveAsText(filename + 'TRials_HTLF_OD.csv', delim=',',
                stimOut=params,
                dataOut=['n','all_mean','all_std', 'all_raw'])
            
            # --- Prepare to start Routine "Break" ---
            # create an object to store info about Routine Break
            Break = data.Routine(
                name='Break',
                components=[image_Frame_Break, image_Cross_Break],
            )
            Break.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            # store start times for Break
            Break.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            Break.tStart = globalClock.getTime(format='float')
            Break.status = STARTED
            thisExp.addData('Break.started', Break.tStart)
            Break.maxDuration = None
            # keep track of which components have finished
            BreakComponents = Break.components
            for thisComponent in Break.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "Break" ---
            # if trial has changed, end Routine now
            if isinstance(Outerloop, data.TrialHandler2) and thisOuterloop.thisN != Outerloop.thisTrial.thisN:
                continueRoutine = False
            Break.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 1.0:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *image_Frame_Break* updates
                
                # if image_Frame_Break is starting this frame...
                if image_Frame_Break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    image_Frame_Break.frameNStart = frameN  # exact frame index
                    image_Frame_Break.tStart = t  # local t and not account for scr refresh
                    image_Frame_Break.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_Frame_Break, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_Frame_Break.started')
                    # update status
                    image_Frame_Break.status = STARTED
                    image_Frame_Break.setAutoDraw(True)
                
                # if image_Frame_Break is active this frame...
                if image_Frame_Break.status == STARTED:
                    # update params
                    pass
                
                # if image_Frame_Break is stopping this frame...
                if image_Frame_Break.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_Frame_Break.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        image_Frame_Break.tStop = t  # not accounting for scr refresh
                        image_Frame_Break.tStopRefresh = tThisFlipGlobal  # on global time
                        image_Frame_Break.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Frame_Break.stopped')
                        # update status
                        image_Frame_Break.status = FINISHED
                        image_Frame_Break.setAutoDraw(False)
                
                # *image_Cross_Break* updates
                
                # if image_Cross_Break is starting this frame...
                if image_Cross_Break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    image_Cross_Break.frameNStart = frameN  # exact frame index
                    image_Cross_Break.tStart = t  # local t and not account for scr refresh
                    image_Cross_Break.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_Cross_Break, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_Cross_Break.started')
                    # update status
                    image_Cross_Break.status = STARTED
                    image_Cross_Break.setAutoDraw(True)
                
                # if image_Cross_Break is active this frame...
                if image_Cross_Break.status == STARTED:
                    # update params
                    pass
                
                # if image_Cross_Break is stopping this frame...
                if image_Cross_Break.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_Cross_Break.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        image_Cross_Break.tStop = t  # not accounting for scr refresh
                        image_Cross_Break.tStopRefresh = tThisFlipGlobal  # on global time
                        image_Cross_Break.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cross_Break.stopped')
                        # update status
                        image_Cross_Break.status = FINISHED
                        image_Cross_Break.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer], 
                        playbackComponents=[]
                    )
                    # skip the frame we paused on
                    continue
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    Break.forceEnded = routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in Break.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "Break" ---
            for thisComponent in Break.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for Break
            Break.tStop = globalClock.getTime(format='float')
            Break.tStopRefresh = tThisFlipGlobal
            thisExp.addData('Break.stopped', Break.tStop)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if Break.maxDurationReached:
                routineTimer.addTime(-Break.maxDuration)
            elif Break.forceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.000000)
            
        #Custom-Comment: End TDA_L
        elif my_seq_num[my_outerloopcounter]==2:
        #Custom-Comment: Start TDA_R
        
            # set up handler to look after randomisation of conditions etc
            Trials_HTLU_OD = data.TrialHandler2(
                name='Trials_HTLU_OD',
                nReps=1.0, 
                method='random', 
                extraInfo=expInfo, 
                originPath=-1, 
                trialList=data.importConditions('Conditions_TR_ND.xlsx'), 
                seed=None, 
            )
            thisExp.addLoop(Trials_HTLU_OD)  # add the loop to the experiment
            thisTrials_HTLU_OD = Trials_HTLU_OD.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTrials_HTLU_OD.rgb)
            if thisTrials_HTLU_OD != None:
                for paramName in thisTrials_HTLU_OD:
                    globals()[paramName] = thisTrials_HTLU_OD[paramName]
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
                
            #--- CUSTOM START ---
            my_TDAR_counter = 0
            #--- CUSTOM END ---
            
            for thisTrials_HTLU_OD in Trials_HTLU_OD:
                currentLoop = Trials_HTLU_OD
                thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
                if thisSession is not None:
                    # if running in a Session with a Liaison client, send data up to now
                    thisSession.sendExperimentData()
                # abbreviate parameter names if possible (e.g. rgb = thisTrials_HTLU_OD.rgb)
                if thisTrials_HTLU_OD != None:
                    for paramName in thisTrials_HTLU_OD:
                        globals()[paramName] = thisTrials_HTLU_OD[paramName]
                
                # --- Prepare to start Routine "HTLU_OD" ---
                # create an object to store info about Routine HTLU_OD
                HTLU_OD = data.Routine(
                    name='HTLU_OD',
                    components=[image1_HTLU_OD, image2_HTLU_OD, image3_HTLU_OD, image4_HTLU_OD, image5_HTLU_OD, image6_HTLU_OD, image7_HTLU_OD, image8_HTLU_OD, image9_HTLU_OD, image10_HTLU_OD, image11_HTLU_OD, image12_HTLU_OD, image13_HTLU_OD, image14_HTLU_OD, image15_HTLU_OD, image16_HTLU_OD, image17_HTLU_OD, image18_HTLU_OD, image19_HTLU_OD, image20_HTLU_OD, image21_HTLU_OD, image22_HTLU_OD, image23_HTLU_OD, image24_HTLU_OD, iamge_Frame_HTLU_OD, image_Cue_HTLU_OD, image_Cross_HTLU_OD, image_Tar_HTLU_OD, key_HTLU_OD],
                )
                HTLU_OD.status = NOT_STARTED
                continueRoutine = True
                # update component parameters for each repeat
                #--- CUSTOM START ---
                image_Tar_HTLU_OD.setPos((my_coordTDA_R[0, my_TDAR_counter, my_outerloopcounter], my_coordTDA_R[1, my_TDAR_counter, my_outerloopcounter]))
                # replaces the old line 'image_Tar_HTLU.setPos((target_xcoor, target_ycoor))'
                #--- CUSTOM END ---
                # create starting attributes for key_HTLU_OD
                key_HTLU_OD.keys = []
                key_HTLU_OD.rt = []
                _key_HTLU_OD_allKeys = []
                # store start times for HTLU_OD
                HTLU_OD.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
                HTLU_OD.tStart = globalClock.getTime(format='float')
                HTLU_OD.status = STARTED
                thisExp.addData('HTLU_OD.started', HTLU_OD.tStart)
                HTLU_OD.maxDuration = None
                # keep track of which components have finished
                HTLU_ODComponents = HTLU_OD.components
                for thisComponent in HTLU_OD.components:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "HTLU_OD" ---
                # if trial has changed, end Routine now
                if isinstance(Trials_HTLU_OD, data.TrialHandler2) and thisTrials_HTLU_OD.thisN != Trials_HTLU_OD.thisTrial.thisN:
                    continueRoutine = False
                HTLU_OD.forceEnded = routineForceEnded = not continueRoutine
                while continueRoutine and routineTimer.getTime() < 1.6:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *image1_HTLU_OD* updates
                    
                    # if image1_HTLU_OD is starting this frame...
                    if image1_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image1_HTLU_OD.frameNStart = frameN  # exact frame index
                        image1_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image1_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image1_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image1_HTLU_OD.started')
                        # update status
                        image1_HTLU_OD.status = STARTED
                        image1_HTLU_OD.setAutoDraw(True)
                    
                    # if image1_HTLU_OD is active this frame...
                    if image1_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image1_HTLU_OD is stopping this frame...
                    if image1_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image1_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image1_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image1_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image1_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image1_HTLU_OD.stopped')
                            # update status
                            image1_HTLU_OD.status = FINISHED
                            image1_HTLU_OD.setAutoDraw(False)
                    
                    # *image2_HTLU_OD* updates
                    
                    # if image2_HTLU_OD is starting this frame...
                    if image2_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.066667-frameTolerance:
                        # keep track of start time/frame for later
                        image2_HTLU_OD.frameNStart = frameN  # exact frame index
                        image2_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image2_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image2_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image2_HTLU_OD.started')
                        # update status
                        image2_HTLU_OD.status = STARTED
                        image2_HTLU_OD.setAutoDraw(True)
                    
                    # if image2_HTLU_OD is active this frame...
                    if image2_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image2_HTLU_OD is stopping this frame...
                    if image2_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image2_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image2_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image2_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image2_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image2_HTLU_OD.stopped')
                            # update status
                            image2_HTLU_OD.status = FINISHED
                            image2_HTLU_OD.setAutoDraw(False)
                    
                    # *image3_HTLU_OD* updates
                    
                    # if image3_HTLU_OD is starting this frame...
                    if image3_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.133334-frameTolerance:
                        # keep track of start time/frame for later
                        image3_HTLU_OD.frameNStart = frameN  # exact frame index
                        image3_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image3_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image3_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image3_HTLU_OD.started')
                        # update status
                        image3_HTLU_OD.status = STARTED
                        image3_HTLU_OD.setAutoDraw(True)
                    
                    # if image3_HTLU_OD is active this frame...
                    if image3_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image3_HTLU_OD is stopping this frame...
                    if image3_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image3_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image3_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image3_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image3_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image3_HTLU_OD.stopped')
                            # update status
                            image3_HTLU_OD.status = FINISHED
                            image3_HTLU_OD.setAutoDraw(False)
                    
                    # *image4_HTLU_OD* updates
                    
                    # if image4_HTLU_OD is starting this frame...
                    if image4_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.200001-frameTolerance:
                        # keep track of start time/frame for later
                        image4_HTLU_OD.frameNStart = frameN  # exact frame index
                        image4_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image4_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image4_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image4_HTLU_OD.started')
                        # update status
                        image4_HTLU_OD.status = STARTED
                        image4_HTLU_OD.setAutoDraw(True)
                    
                    # if image4_HTLU_OD is active this frame...
                    if image4_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image4_HTLU_OD is stopping this frame...
                    if image4_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image4_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image4_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image4_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image4_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image4_HTLU_OD.stopped')
                            # update status
                            image4_HTLU_OD.status = FINISHED
                            image4_HTLU_OD.setAutoDraw(False)
                    
                    # *image5_HTLU_OD* updates
                    
                    # if image5_HTLU_OD is starting this frame...
                    if image5_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.266668-frameTolerance:
                        # keep track of start time/frame for later
                        image5_HTLU_OD.frameNStart = frameN  # exact frame index
                        image5_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image5_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image5_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image5_HTLU_OD.started')
                        # update status
                        image5_HTLU_OD.status = STARTED
                        image5_HTLU_OD.setAutoDraw(True)
                    
                    # if image5_HTLU_OD is active this frame...
                    if image5_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image5_HTLU_OD is stopping this frame...
                    if image5_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image5_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image5_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image5_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image5_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image5_HTLU_OD.stopped')
                            # update status
                            image5_HTLU_OD.status = FINISHED
                            image5_HTLU_OD.setAutoDraw(False)
                    
                    # *image6_HTLU_OD* updates
                    
                    # if image6_HTLU_OD is starting this frame...
                    if image6_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.333335-frameTolerance:
                        # keep track of start time/frame for later
                        image6_HTLU_OD.frameNStart = frameN  # exact frame index
                        image6_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image6_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image6_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image6_HTLU_OD.started')
                        # update status
                        image6_HTLU_OD.status = STARTED
                        image6_HTLU_OD.setAutoDraw(True)
                    
                    # if image6_HTLU_OD is active this frame...
                    if image6_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image6_HTLU_OD is stopping this frame...
                    if image6_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image6_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image6_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image6_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image6_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image6_HTLU_OD.stopped')
                            # update status
                            image6_HTLU_OD.status = FINISHED
                            image6_HTLU_OD.setAutoDraw(False)
                    
                    # *image7_HTLU_OD* updates
                    
                    # if image7_HTLU_OD is starting this frame...
                    if image7_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.400002-frameTolerance:
                        # keep track of start time/frame for later
                        image7_HTLU_OD.frameNStart = frameN  # exact frame index
                        image7_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image7_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image7_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image7_HTLU_OD.started')
                        # update status
                        image7_HTLU_OD.status = STARTED
                        image7_HTLU_OD.setAutoDraw(True)
                    
                    # if image7_HTLU_OD is active this frame...
                    if image7_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image7_HTLU_OD is stopping this frame...
                    if image7_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image7_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image7_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image7_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image7_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image7_HTLU_OD.stopped')
                            # update status
                            image7_HTLU_OD.status = FINISHED
                            image7_HTLU_OD.setAutoDraw(False)
                    
                    # *image8_HTLU_OD* updates
                    
                    # if image8_HTLU_OD is starting this frame...
                    if image8_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.466669-frameTolerance:
                        # keep track of start time/frame for later
                        image8_HTLU_OD.frameNStart = frameN  # exact frame index
                        image8_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image8_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image8_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image8_HTLU_OD.started')
                        # update status
                        image8_HTLU_OD.status = STARTED
                        image8_HTLU_OD.setAutoDraw(True)
                    
                    # if image8_HTLU_OD is active this frame...
                    if image8_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image8_HTLU_OD is stopping this frame...
                    if image8_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image8_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image8_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image8_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image8_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image8_HTLU_OD.stopped')
                            # update status
                            image8_HTLU_OD.status = FINISHED
                            image8_HTLU_OD.setAutoDraw(False)
                    
                    # *image9_HTLU_OD* updates
                    
                    # if image9_HTLU_OD is starting this frame...
                    if image9_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.533336-frameTolerance:
                        # keep track of start time/frame for later
                        image9_HTLU_OD.frameNStart = frameN  # exact frame index
                        image9_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image9_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image9_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image9_HTLU_OD.started')
                        # update status
                        image9_HTLU_OD.status = STARTED
                        image9_HTLU_OD.setAutoDraw(True)
                    
                    # if image9_HTLU_OD is active this frame...
                    if image9_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image9_HTLU_OD is stopping this frame...
                    if image9_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image9_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image9_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image9_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image9_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image9_HTLU_OD.stopped')
                            # update status
                            image9_HTLU_OD.status = FINISHED
                            image9_HTLU_OD.setAutoDraw(False)
                    
                    # *image10_HTLU_OD* updates
                    
                    # if image10_HTLU_OD is starting this frame...
                    if image10_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.600003-frameTolerance:
                        # keep track of start time/frame for later
                        image10_HTLU_OD.frameNStart = frameN  # exact frame index
                        image10_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image10_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image10_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image10_HTLU_OD.started')
                        # update status
                        image10_HTLU_OD.status = STARTED
                        image10_HTLU_OD.setAutoDraw(True)
                    
                    # if image10_HTLU_OD is active this frame...
                    if image10_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image10_HTLU_OD is stopping this frame...
                    if image10_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image10_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image10_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image10_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image10_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image10_HTLU_OD.stopped')
                            # update status
                            image10_HTLU_OD.status = FINISHED
                            image10_HTLU_OD.setAutoDraw(False)
                    
                    # *image11_HTLU_OD* updates
                    
                    # if image11_HTLU_OD is starting this frame...
                    if image11_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.666670-frameTolerance:
                        # keep track of start time/frame for later
                        image11_HTLU_OD.frameNStart = frameN  # exact frame index
                        image11_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image11_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image11_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image11_HTLU_OD.started')
                        # update status
                        image11_HTLU_OD.status = STARTED
                        image11_HTLU_OD.setAutoDraw(True)
                    
                    # if image11_HTLU_OD is active this frame...
                    if image11_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image11_HTLU_OD is stopping this frame...
                    if image11_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image11_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image11_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image11_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image11_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image11_HTLU_OD.stopped')
                            # update status
                            image11_HTLU_OD.status = FINISHED
                            image11_HTLU_OD.setAutoDraw(False)
                    
                    # *image12_HTLU_OD* updates
                    
                    # if image12_HTLU_OD is starting this frame...
                    if image12_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.733337-frameTolerance:
                        # keep track of start time/frame for later
                        image12_HTLU_OD.frameNStart = frameN  # exact frame index
                        image12_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image12_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image12_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image12_HTLU_OD.started')
                        # update status
                        image12_HTLU_OD.status = STARTED
                        image12_HTLU_OD.setAutoDraw(True)
                    
                    # if image12_HTLU_OD is active this frame...
                    if image12_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image12_HTLU_OD is stopping this frame...
                    if image12_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image12_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image12_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image12_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image12_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image12_HTLU_OD.stopped')
                            # update status
                            image12_HTLU_OD.status = FINISHED
                            image12_HTLU_OD.setAutoDraw(False)
                    
                    # *image13_HTLU_OD* updates
                    
                    # if image13_HTLU_OD is starting this frame...
                    if image13_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.800004-frameTolerance:
                        # keep track of start time/frame for later
                        image13_HTLU_OD.frameNStart = frameN  # exact frame index
                        image13_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image13_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image13_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image13_HTLU_OD.started')
                        # update status
                        image13_HTLU_OD.status = STARTED
                        image13_HTLU_OD.setAutoDraw(True)
                    
                    # if image13_HTLU_OD is active this frame...
                    if image13_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image13_HTLU_OD is stopping this frame...
                    if image13_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image13_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image13_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image13_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image13_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image13_HTLU_OD.stopped')
                            # update status
                            image13_HTLU_OD.status = FINISHED
                            image13_HTLU_OD.setAutoDraw(False)
                    
                    # *image14_HTLU_OD* updates
                    
                    # if image14_HTLU_OD is starting this frame...
                    if image14_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.866671-frameTolerance:
                        # keep track of start time/frame for later
                        image14_HTLU_OD.frameNStart = frameN  # exact frame index
                        image14_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image14_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image14_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image14_HTLU_OD.started')
                        # update status
                        image14_HTLU_OD.status = STARTED
                        image14_HTLU_OD.setAutoDraw(True)
                    
                    # if image14_HTLU_OD is active this frame...
                    if image14_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image14_HTLU_OD is stopping this frame...
                    if image14_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image14_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image14_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image14_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image14_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image14_HTLU_OD.stopped')
                            # update status
                            image14_HTLU_OD.status = FINISHED
                            image14_HTLU_OD.setAutoDraw(False)
                    
                    # *image15_HTLU_OD* updates
                    
                    # if image15_HTLU_OD is starting this frame...
                    if image15_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.933338-frameTolerance:
                        # keep track of start time/frame for later
                        image15_HTLU_OD.frameNStart = frameN  # exact frame index
                        image15_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image15_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image15_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image15_HTLU_OD.started')
                        # update status
                        image15_HTLU_OD.status = STARTED
                        image15_HTLU_OD.setAutoDraw(True)
                    
                    # if image15_HTLU_OD is active this frame...
                    if image15_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image15_HTLU_OD is stopping this frame...
                    if image15_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image15_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image15_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image15_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image15_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image15_HTLU_OD.stopped')
                            # update status
                            image15_HTLU_OD.status = FINISHED
                            image15_HTLU_OD.setAutoDraw(False)
                    
                    # *image16_HTLU_OD* updates
                    
                    # if image16_HTLU_OD is starting this frame...
                    if image16_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.000005-frameTolerance:
                        # keep track of start time/frame for later
                        image16_HTLU_OD.frameNStart = frameN  # exact frame index
                        image16_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image16_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image16_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image16_HTLU_OD.started')
                        # update status
                        image16_HTLU_OD.status = STARTED
                        image16_HTLU_OD.setAutoDraw(True)
                    
                    # if image16_HTLU_OD is active this frame...
                    if image16_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image16_HTLU_OD is stopping this frame...
                    if image16_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image16_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image16_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image16_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image16_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image16_HTLU_OD.stopped')
                            # update status
                            image16_HTLU_OD.status = FINISHED
                            image16_HTLU_OD.setAutoDraw(False)
                    
                    # *image17_HTLU_OD* updates
                    
                    # if image17_HTLU_OD is starting this frame...
                    if image17_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.066672-frameTolerance:
                        # keep track of start time/frame for later
                        image17_HTLU_OD.frameNStart = frameN  # exact frame index
                        image17_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image17_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image17_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image17_HTLU_OD.started')
                        # update status
                        image17_HTLU_OD.status = STARTED
                        image17_HTLU_OD.setAutoDraw(True)
                    
                    # if image17_HTLU_OD is active this frame...
                    if image17_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image17_HTLU_OD is stopping this frame...
                    if image17_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image17_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image17_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image17_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image17_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image17_HTLU_OD.stopped')
                            # update status
                            image17_HTLU_OD.status = FINISHED
                            image17_HTLU_OD.setAutoDraw(False)
                    
                    # *image18_HTLU_OD* updates
                    
                    # if image18_HTLU_OD is starting this frame...
                    if image18_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.133339-frameTolerance:
                        # keep track of start time/frame for later
                        image18_HTLU_OD.frameNStart = frameN  # exact frame index
                        image18_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image18_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image18_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image18_HTLU_OD.started')
                        # update status
                        image18_HTLU_OD.status = STARTED
                        image18_HTLU_OD.setAutoDraw(True)
                    
                    # if image18_HTLU_OD is active this frame...
                    if image18_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image18_HTLU_OD is stopping this frame...
                    if image18_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image18_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image18_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image18_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image18_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image18_HTLU_OD.stopped')
                            # update status
                            image18_HTLU_OD.status = FINISHED
                            image18_HTLU_OD.setAutoDraw(False)
                    
                    # *image19_HTLU_OD* updates
                    
                    # if image19_HTLU_OD is starting this frame...
                    if image19_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.200006-frameTolerance:
                        # keep track of start time/frame for later
                        image19_HTLU_OD.frameNStart = frameN  # exact frame index
                        image19_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image19_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image19_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image19_HTLU_OD.started')
                        # update status
                        image19_HTLU_OD.status = STARTED
                        image19_HTLU_OD.setAutoDraw(True)
                    
                    # if image19_HTLU_OD is active this frame...
                    if image19_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image19_HTLU_OD is stopping this frame...
                    if image19_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image19_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image19_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image19_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image19_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image19_HTLU_OD.stopped')
                            # update status
                            image19_HTLU_OD.status = FINISHED
                            image19_HTLU_OD.setAutoDraw(False)
                    
                    # *image20_HTLU_OD* updates
                    
                    # if image20_HTLU_OD is starting this frame...
                    if image20_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.266673-frameTolerance:
                        # keep track of start time/frame for later
                        image20_HTLU_OD.frameNStart = frameN  # exact frame index
                        image20_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image20_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image20_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image20_HTLU_OD.started')
                        # update status
                        image20_HTLU_OD.status = STARTED
                        image20_HTLU_OD.setAutoDraw(True)
                    
                    # if image20_HTLU_OD is active this frame...
                    if image20_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image20_HTLU_OD is stopping this frame...
                    if image20_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image20_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image20_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image20_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image20_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image20_HTLU_OD.stopped')
                            # update status
                            image20_HTLU_OD.status = FINISHED
                            image20_HTLU_OD.setAutoDraw(False)
                    
                    # *image21_HTLU_OD* updates
                    
                    # if image21_HTLU_OD is starting this frame...
                    if image21_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.333340-frameTolerance:
                        # keep track of start time/frame for later
                        image21_HTLU_OD.frameNStart = frameN  # exact frame index
                        image21_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image21_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image21_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image21_HTLU_OD.started')
                        # update status
                        image21_HTLU_OD.status = STARTED
                        image21_HTLU_OD.setAutoDraw(True)
                    
                    # if image21_HTLU_OD is active this frame...
                    if image21_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image21_HTLU_OD is stopping this frame...
                    if image21_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image21_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image21_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image21_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image21_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image21_HTLU_OD.stopped')
                            # update status
                            image21_HTLU_OD.status = FINISHED
                            image21_HTLU_OD.setAutoDraw(False)
                    
                    # *image22_HTLU_OD* updates
                    
                    # if image22_HTLU_OD is starting this frame...
                    if image22_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.400007-frameTolerance:
                        # keep track of start time/frame for later
                        image22_HTLU_OD.frameNStart = frameN  # exact frame index
                        image22_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image22_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image22_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image22_HTLU_OD.started')
                        # update status
                        image22_HTLU_OD.status = STARTED
                        image22_HTLU_OD.setAutoDraw(True)
                    
                    # if image22_HTLU_OD is active this frame...
                    if image22_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image22_HTLU_OD is stopping this frame...
                    if image22_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image22_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image22_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image22_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image22_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image22_HTLU_OD.stopped')
                            # update status
                            image22_HTLU_OD.status = FINISHED
                            image22_HTLU_OD.setAutoDraw(False)
                    
                    # *image23_HTLU_OD* updates
                    
                    # if image23_HTLU_OD is starting this frame...
                    if image23_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.466674-frameTolerance:
                        # keep track of start time/frame for later
                        image23_HTLU_OD.frameNStart = frameN  # exact frame index
                        image23_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image23_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image23_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image23_HTLU_OD.started')
                        # update status
                        image23_HTLU_OD.status = STARTED
                        image23_HTLU_OD.setAutoDraw(True)
                    
                    # if image23_HTLU_OD is active this frame...
                    if image23_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image23_HTLU_OD is stopping this frame...
                    if image23_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image23_HTLU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image23_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image23_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image23_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image23_HTLU_OD.stopped')
                            # update status
                            image23_HTLU_OD.status = FINISHED
                            image23_HTLU_OD.setAutoDraw(False)
                    
                    # *image24_HTLU_OD* updates
                    
                    # if image24_HTLU_OD is starting this frame...
                    if image24_HTLU_OD.status == NOT_STARTED and tThisFlip >= 1.533341-frameTolerance:
                        # keep track of start time/frame for later
                        image24_HTLU_OD.frameNStart = frameN  # exact frame index
                        image24_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image24_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image24_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image24_HTLU_OD.started')
                        # update status
                        image24_HTLU_OD.status = STARTED
                        image24_HTLU_OD.setAutoDraw(True)
                    
                    # if image24_HTLU_OD is active this frame...
                    if image24_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image24_HTLU_OD is stopping this frame...
                    if image24_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image24_HTLU_OD.tStartRefresh + 0.066659-frameTolerance:
                            # keep track of stop time/frame for later
                            image24_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image24_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image24_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image24_HTLU_OD.stopped')
                            # update status
                            image24_HTLU_OD.status = FINISHED
                            image24_HTLU_OD.setAutoDraw(False)
                    
                    # *iamge_Frame_HTLU_OD* updates
                    
                    # if iamge_Frame_HTLU_OD is starting this frame...
                    if iamge_Frame_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        iamge_Frame_HTLU_OD.frameNStart = frameN  # exact frame index
                        iamge_Frame_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        iamge_Frame_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(iamge_Frame_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'iamge_Frame_HTLU_OD.started')
                        # update status
                        iamge_Frame_HTLU_OD.status = STARTED
                        iamge_Frame_HTLU_OD.setAutoDraw(True)
                    
                    # if iamge_Frame_HTLU_OD is active this frame...
                    if iamge_Frame_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if iamge_Frame_HTLU_OD is stopping this frame...
                    if iamge_Frame_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > iamge_Frame_HTLU_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            iamge_Frame_HTLU_OD.tStop = t  # not accounting for scr refresh
                            iamge_Frame_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            iamge_Frame_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'iamge_Frame_HTLU_OD.stopped')
                            # update status
                            iamge_Frame_HTLU_OD.status = FINISHED
                            iamge_Frame_HTLU_OD.setAutoDraw(False)
                    
                    # *image_Cue_HTLU_OD* updates
                    
                    # if image_Cue_HTLU_OD is starting this frame...
                    if image_Cue_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Cue_HTLU_OD.frameNStart = frameN  # exact frame index
                        image_Cue_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image_Cue_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Cue_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cue_HTLU_OD.started')
                        # update status
                        image_Cue_HTLU_OD.status = STARTED
                        image_Cue_HTLU_OD.setAutoDraw(True)
                    
                    # if image_Cue_HTLU_OD is active this frame...
                    if image_Cue_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Cue_HTLU_OD is stopping this frame...
                    if image_Cue_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Cue_HTLU_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Cue_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image_Cue_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Cue_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Cue_HTLU_OD.stopped')
                            # update status
                            image_Cue_HTLU_OD.status = FINISHED
                            image_Cue_HTLU_OD.setAutoDraw(False)
                    
                    # *image_Cross_HTLU_OD* updates
                    
                    # if image_Cross_HTLU_OD is starting this frame...
                    if image_Cross_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Cross_HTLU_OD.frameNStart = frameN  # exact frame index
                        image_Cross_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image_Cross_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Cross_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cross_HTLU_OD.started')
                        # update status
                        image_Cross_HTLU_OD.status = STARTED
                        image_Cross_HTLU_OD.setAutoDraw(True)
                    
                    # if image_Cross_HTLU_OD is active this frame...
                    if image_Cross_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Cross_HTLU_OD is stopping this frame...
                    if image_Cross_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Cross_HTLU_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Cross_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image_Cross_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Cross_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Cross_HTLU_OD.stopped')
                            # update status
                            image_Cross_HTLU_OD.status = FINISHED
                            image_Cross_HTLU_OD.setAutoDraw(False)
                    
                    # *image_Tar_HTLU_OD* updates
                    
                    # if image_Tar_HTLU_OD is starting this frame...
                    if image_Tar_HTLU_OD.status == NOT_STARTED and tThisFlip >= (1.6 - my_randtartime[my_randtartime_counter])-frameTolerance:   ### CUSTOM START AND END 
                        # keep track of start time/frame for later
                        image_Tar_HTLU_OD.frameNStart = frameN  # exact frame index
                        image_Tar_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        image_Tar_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Tar_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Tar_HTLU_OD.started')
                        # update status
                        image_Tar_HTLU_OD.status = STARTED
                        image_Tar_HTLU_OD.setAutoDraw(True)
                    
                    # if image_Tar_HTLU_OD is active this frame...
                    if image_Tar_HTLU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Tar_HTLU_OD is stopping this frame...
                    if image_Tar_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Tar_HTLU_OD.tStartRefresh + my_randtartime[my_randtartime_counter]-frameTolerance:         ### CUSTOM START AND END
                            # keep track of stop time/frame for later
                            image_Tar_HTLU_OD.tStop = t  # not accounting for scr refresh
                            image_Tar_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Tar_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Tar_HTLU_OD.stopped')
                            # update status
                            image_Tar_HTLU_OD.status = FINISHED
                            image_Tar_HTLU_OD.setAutoDraw(False)
                    
                    # *key_HTLU_OD* updates
                    waitOnFlip = False
                    
                    # if key_HTLU_OD is starting this frame...
                    if key_HTLU_OD.status == NOT_STARTED and tThisFlip >= 0.1-frameTolerance:
                        # keep track of start time/frame for later
                        key_HTLU_OD.frameNStart = frameN  # exact frame index
                        key_HTLU_OD.tStart = t  # local t and not account for scr refresh
                        key_HTLU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(key_HTLU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'key_HTLU_OD.started')
                        # update status
                        key_HTLU_OD.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(key_HTLU_OD.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(key_HTLU_OD.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    
                    # if key_HTLU_OD is stopping this frame...
                    if key_HTLU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > key_HTLU_OD.tStartRefresh + 1.5-frameTolerance:
                            # keep track of stop time/frame for later
                            key_HTLU_OD.tStop = t  # not accounting for scr refresh
                            key_HTLU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            key_HTLU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'key_HTLU_OD.stopped')
                            # update status
                            key_HTLU_OD.status = FINISHED
                            key_HTLU_OD.status = FINISHED
                    if key_HTLU_OD.status == STARTED and not waitOnFlip:
                        theseKeys = key_HTLU_OD.getKeys(keyList=['1'], ignoreKeys=["escape"], waitRelease=False)
                        _key_HTLU_OD_allKeys.extend(theseKeys)
                        if len(_key_HTLU_OD_allKeys):
                            key_HTLU_OD.keys = _key_HTLU_OD_allKeys[0].name  # just the first key pressed
                            key_HTLU_OD.rt = _key_HTLU_OD_allKeys[0].rt
                            key_HTLU_OD.duration = _key_HTLU_OD_allKeys[0].duration
                            # was this correct?
                            ### CUSTOM START ###
                            #if (key_HTLU.keys == str(corr_resp)) or (key_HTLU.keys == corr_resp):
                            if (key_HTLU_OD.keys == str(my_corrResp_R[my_outerloopcounter][my_TDAR_counter])) or (key_HTLU_OD.keys == my_corrResp_R[my_outerloopcounter][my_TDAR_counter]): ## CUSTOM: Replaced corr_resp with own variable my_corrResp_*
                                key_HTLU_OD.corr = 1
                            else:
                                key_HTLU_OD.corr = 0
                            ### CUSTOM END ###
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, win=win)
                        return
                    # pause experiment here if requested
                    if thisExp.status == PAUSED:
                        pauseExperiment(
                            thisExp=thisExp, 
                            win=win, 
                            timers=[routineTimer], 
                            playbackComponents=[]
                        )
                        # skip the frame we paused on
                        continue
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        HTLU_OD.forceEnded = routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in HTLU_OD.components:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                my_randtartime_counter = my_randtartime_counter + 1          ### CUSTOM START AND END
                
                # --- Ending Routine "HTLU_OD" ---
                for thisComponent in HTLU_OD.components:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                # store stop times for HTLU_OD
                HTLU_OD.tStop = globalClock.getTime(format='float')
                HTLU_OD.tStopRefresh = tThisFlipGlobal
                thisExp.addData('HTLU_OD.stopped', HTLU_OD.tStop)
                # check responses
                if key_HTLU_OD.keys in ['', [], None]:  # No response was made
                    key_HTLU_OD.keys = None
                    # was no response the correct answer?!
                    if str(my_corrResp_R[my_outerloopcounter][my_TDAR_counter]).lower() == 'none': ## CUSTOM START & END
                       key_HTLU_OD.corr = 1;  # correct non-response
                    else:
                       key_HTLU_OD.corr = 0;  # failed to respond (incorrectly)
                # store data for Trials_HTLU_OD (TrialHandler)
                Trials_HTLU_OD.addData('key_HTLU_OD.keys',key_HTLU_OD.keys)
                Trials_HTLU_OD.addData('key_HTLU_OD.corr', key_HTLU_OD.corr)
                if key_HTLU_OD.keys != None:  # we had a response
                    Trials_HTLU_OD.addData('key_HTLU_OD.rt', key_HTLU_OD.rt)
                    Trials_HTLU_OD.addData('key_HTLU_OD.duration', key_HTLU_OD.duration)
                try:
                    if image1_HTLU_OD.tStopRefresh is not None:
                        duration_val = image1_HTLU_OD.tStopRefresh - image1_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image1_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image1_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image1_HTLU_OD).__name__,
                        trial_type='image1_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image1_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image2_HTLU_OD.tStopRefresh is not None:
                        duration_val = image2_HTLU_OD.tStopRefresh - image2_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image2_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image2_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image2_HTLU_OD).__name__,
                        trial_type='image2_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image2_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image3_HTLU_OD.tStopRefresh is not None:
                        duration_val = image3_HTLU_OD.tStopRefresh - image3_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image3_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image3_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image3_HTLU_OD).__name__,
                        trial_type='image3_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image3_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image4_HTLU_OD.tStopRefresh is not None:
                        duration_val = image4_HTLU_OD.tStopRefresh - image4_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image4_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image4_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image4_HTLU_OD).__name__,
                        trial_type='image4_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image4_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image5_HTLU_OD.tStopRefresh is not None:
                        duration_val = image5_HTLU_OD.tStopRefresh - image5_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image5_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image5_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image5_HTLU_OD).__name__,
                        trial_type='image5_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image5_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image6_HTLU_OD.tStopRefresh is not None:
                        duration_val = image6_HTLU_OD.tStopRefresh - image6_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image6_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image6_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image6_HTLU_OD).__name__,
                        trial_type='image6_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image6_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image7_HTLU_OD.tStopRefresh is not None:
                        duration_val = image7_HTLU_OD.tStopRefresh - image7_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image7_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image7_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image7_HTLU_OD).__name__,
                        trial_type='image7_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image7_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image8_HTLU_OD.tStopRefresh is not None:
                        duration_val = image8_HTLU_OD.tStopRefresh - image8_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image8_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image8_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image8_HTLU_OD).__name__,
                        trial_type='image8_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image8_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image9_HTLU_OD.tStopRefresh is not None:
                        duration_val = image9_HTLU_OD.tStopRefresh - image9_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image9_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image9_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image9_HTLU_OD).__name__,
                        trial_type='image9_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image9_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image10_HTLU_OD.tStopRefresh is not None:
                        duration_val = image10_HTLU_OD.tStopRefresh - image10_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image10_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image10_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image10_HTLU_OD).__name__,
                        trial_type='image10_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image10_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image11_HTLU_OD.tStopRefresh is not None:
                        duration_val = image11_HTLU_OD.tStopRefresh - image11_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image11_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image11_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image11_HTLU_OD).__name__,
                        trial_type='image11_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image11_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image12_HTLU_OD.tStopRefresh is not None:
                        duration_val = image12_HTLU_OD.tStopRefresh - image12_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image12_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image12_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image12_HTLU_OD).__name__,
                        trial_type='image12_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image12_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image13_HTLU_OD.tStopRefresh is not None:
                        duration_val = image13_HTLU_OD.tStopRefresh - image13_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image13_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image13_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image13_HTLU_OD).__name__,
                        trial_type='image13_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image13_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image14_HTLU_OD.tStopRefresh is not None:
                        duration_val = image14_HTLU_OD.tStopRefresh - image14_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image14_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image14_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image14_HTLU_OD).__name__,
                        trial_type='image14_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image14_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image15_HTLU_OD.tStopRefresh is not None:
                        duration_val = image15_HTLU_OD.tStopRefresh - image15_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image15_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image15_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image15_HTLU_OD).__name__,
                        trial_type='image15_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image15_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image16_HTLU_OD.tStopRefresh is not None:
                        duration_val = image16_HTLU_OD.tStopRefresh - image16_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image16_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image16_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image16_HTLU_OD).__name__,
                        trial_type='image16_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image16_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image17_HTLU_OD.tStopRefresh is not None:
                        duration_val = image17_HTLU_OD.tStopRefresh - image17_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image17_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image17_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image17_HTLU_OD).__name__,
                        trial_type='image17_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image17_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image18_HTLU_OD.tStopRefresh is not None:
                        duration_val = image18_HTLU_OD.tStopRefresh - image18_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image18_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image18_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image18_HTLU_OD).__name__,
                        trial_type='image18_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image18_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image19_HTLU_OD.tStopRefresh is not None:
                        duration_val = image19_HTLU_OD.tStopRefresh - image19_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image19_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image19_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image19_HTLU_OD).__name__,
                        trial_type='image19_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image19_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image20_HTLU_OD.tStopRefresh is not None:
                        duration_val = image20_HTLU_OD.tStopRefresh - image20_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image20_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image20_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image20_HTLU_OD).__name__,
                        trial_type='image20_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image20_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image21_HTLU_OD.tStopRefresh is not None:
                        duration_val = image21_HTLU_OD.tStopRefresh - image21_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image21_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image21_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image21_HTLU_OD).__name__,
                        trial_type='image21_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image21_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image22_HTLU_OD.tStopRefresh is not None:
                        duration_val = image22_HTLU_OD.tStopRefresh - image22_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image22_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image22_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image22_HTLU_OD).__name__,
                        trial_type='image22_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image22_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image23_HTLU_OD.tStopRefresh is not None:
                        duration_val = image23_HTLU_OD.tStopRefresh - image23_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image23_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image23_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image23_HTLU_OD).__name__,
                        trial_type='image23_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image23_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image24_HTLU_OD.tStopRefresh is not None:
                        duration_val = image24_HTLU_OD.tStopRefresh - image24_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image24_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image24_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image24_HTLU_OD).__name__,
                        trial_type='image24_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image24_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image_Cue_HTLU_OD.tStopRefresh is not None:
                        duration_val = image_Cue_HTLU_OD.tStopRefresh - image_Cue_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image_Cue_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image_Cue_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image_Cue_HTLU_OD).__name__,
                        trial_type='image_Cue_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image_Cue_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image_Tar_HTLU_OD.tStopRefresh is not None:
                        duration_val = image_Tar_HTLU_OD.tStopRefresh - image_Tar_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - image_Tar_HTLU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image_Tar_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image_Tar_HTLU_OD).__name__,
                        trial_type='image_Tar_HTLU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_image_Tar_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if key_HTLU_OD.tStopRefresh is not None:
                        duration_val = key_HTLU_OD.tStopRefresh - key_HTLU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTLU_OD.stopped'] - key_HTLU_OD.tStartRefresh
                    if hasattr(key_HTLU_OD, 'rt'):
                        rt_val = key_HTLU_OD.rt
                    else:
                        rt_val = None
                        logging.warning('The linked component "key_HTLU_OD" does not have a reaction time(.rt) attribute. Unable to link BIDS response_time to this component. Please verify the component settings.')
                    bids_event = BIDSTaskEvent(
                        onset=key_HTLU_OD.tStartRefresh,
                        duration=duration_val,
                        response_time=rt_val,
                        event_type=type(key_HTLU_OD).__name__,
                        trial_type='key_HTLU_OD',
                        value=key_HTLU_OD.corr,
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTLU_OD.addData('bidsEvent_key_HTLU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
                if HTLU_OD.maxDurationReached:
                    routineTimer.addTime(-HTLU_OD.maxDuration)
                elif HTLU_OD.forceEnded:
                    routineTimer.reset()
                else:
                    routineTimer.addTime(-1.600000)
                thisExp.nextEntry()
                
                #--- CUSTOM START ---
                my_TDAR_counter = my_TDAR_counter + 1
                #--- CUSTOM END ---
                
            # completed 1.0 repeats of 'Trials_HTLU_OD'
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            # get names of stimulus parameters
            if Trials_HTLU_OD.trialList in ([], [None], None):
                params = []
            else:
                params = Trials_HTLU_OD.trialList[0].keys()
            # save data for this loop
            Trials_HTLU_OD.saveAsExcel(filename + '.xlsx', sheetName='Trials_HTLU_OD',
                stimOut=params,
                dataOut=['n','all_mean','all_std', 'all_raw'])
            Trials_HTLU_OD.saveAsText(filename + 'Trials_HTLU_OD.csv', delim=',',
                stimOut=params,
                dataOut=['n','all_mean','all_std', 'all_raw'])
            
            # --- Prepare to start Routine "Break" ---
            # create an object to store info about Routine Break
            Break = data.Routine(
                name='Break',
                components=[image_Frame_Break, image_Cross_Break],
            )
            Break.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            # store start times for Break
            Break.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            Break.tStart = globalClock.getTime(format='float')
            Break.status = STARTED
            thisExp.addData('Break.started', Break.tStart)
            Break.maxDuration = None
            # keep track of which components have finished
            BreakComponents = Break.components
            for thisComponent in Break.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "Break" ---
            # if trial has changed, end Routine now
            if isinstance(Outerloop, data.TrialHandler2) and thisOuterloop.thisN != Outerloop.thisTrial.thisN:
                continueRoutine = False
            Break.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 1.0:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *image_Frame_Break* updates
                
                # if image_Frame_Break is starting this frame...
                if image_Frame_Break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    image_Frame_Break.frameNStart = frameN  # exact frame index
                    image_Frame_Break.tStart = t  # local t and not account for scr refresh
                    image_Frame_Break.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_Frame_Break, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_Frame_Break.started')
                    # update status
                    image_Frame_Break.status = STARTED
                    image_Frame_Break.setAutoDraw(True)
                
                # if image_Frame_Break is active this frame...
                if image_Frame_Break.status == STARTED:
                    # update params
                    pass
                
                # if image_Frame_Break is stopping this frame...
                if image_Frame_Break.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_Frame_Break.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        image_Frame_Break.tStop = t  # not accounting for scr refresh
                        image_Frame_Break.tStopRefresh = tThisFlipGlobal  # on global time
                        image_Frame_Break.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Frame_Break.stopped')
                        # update status
                        image_Frame_Break.status = FINISHED
                        image_Frame_Break.setAutoDraw(False)
                
                # *image_Cross_Break* updates
                
                # if image_Cross_Break is starting this frame...
                if image_Cross_Break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    image_Cross_Break.frameNStart = frameN  # exact frame index
                    image_Cross_Break.tStart = t  # local t and not account for scr refresh
                    image_Cross_Break.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_Cross_Break, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_Cross_Break.started')
                    # update status
                    image_Cross_Break.status = STARTED
                    image_Cross_Break.setAutoDraw(True)
                
                # if image_Cross_Break is active this frame...
                if image_Cross_Break.status == STARTED:
                    # update params
                    pass
                
                # if image_Cross_Break is stopping this frame...
                if image_Cross_Break.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_Cross_Break.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        image_Cross_Break.tStop = t  # not accounting for scr refresh
                        image_Cross_Break.tStopRefresh = tThisFlipGlobal  # on global time
                        image_Cross_Break.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cross_Break.stopped')
                        # update status
                        image_Cross_Break.status = FINISHED
                        image_Cross_Break.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer], 
                        playbackComponents=[]
                    )
                    # skip the frame we paused on
                    continue
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    Break.forceEnded = routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in Break.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "Break" ---
            for thisComponent in Break.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for Break
            Break.tStop = globalClock.getTime(format='float')
            Break.tStopRefresh = tThisFlipGlobal
            thisExp.addData('Break.stopped', Break.tStop)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if Break.maxDurationReached:
                routineTimer.addTime(-Break.maxDuration)
            elif Break.forceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.000000)
            
        #Custom-Comment: End TDA_R
        elif my_seq_num[my_outerloopcounter]==3:
        #Custom-Comment: Start TDA_GL
        
            # set up handler to look after randomisation of conditions etc
            Trials_HTRF_OD = data.TrialHandler2(
                name='Trials_HTRF_OD',
                nReps=1.0, 
                method='random', 
                extraInfo=expInfo, 
                originPath=-1, 
                trialList=data.importConditions('Conditions_TR_ND.xlsx'), 
                seed=None, 
            )
            thisExp.addLoop(Trials_HTRF_OD)  # add the loop to the experiment
            thisTrials_HTRF_OD = Trials_HTRF_OD.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTrials_HTRF_OD.rgb)
            if thisTrials_HTRF_OD != None:
                for paramName in thisTrials_HTRF_OD:
                    globals()[paramName] = thisTrials_HTRF_OD[paramName]
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            
            #--- CUSTOM START ---
            my_TDAGL_counter = 0
            #--- CUSTOM END ---
            
            for thisTrials_HTRF_OD in Trials_HTRF_OD:
                currentLoop = Trials_HTRF_OD
                thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
                if thisSession is not None:
                    # if running in a Session with a Liaison client, send data up to now
                    thisSession.sendExperimentData()
                # abbreviate parameter names if possible (e.g. rgb = thisTrials_HTRF_OD.rgb)
                if thisTrials_HTRF_OD != None:
                    for paramName in thisTrials_HTRF_OD:
                        globals()[paramName] = thisTrials_HTRF_OD[paramName]
                
                # --- Prepare to start Routine "HTRF_OD" ---
                # create an object to store info about Routine HTRF_OD
                HTRF_OD = data.Routine(
                    name='HTRF_OD',
                    components=[image1_HTRF_OD, image2_HTRF_OD, image3_HTRF_OD, image4_HTRF_OD, image5_HTRF_OD, image6_HTRF_OD, image7_HTRF_OD, image8_HTRF_OD, image9_HTRF_OD, image10_HTRF_OD, image11_HTRF_OD, image12_HTRF_OD, image13_HTRF_OD, image14_HTRF_OD, image15_HTRF_OD, image16_HTRF_OD, image17_HTRF_OD, image18_HTRF_OD, image19_HTRF_OD, image20_HTRF_OD, image21_HTRF_OD, image22_HTRF_OD, image23_HTRF_OD, image24_HTRF_OD, image_Frame_HTRF_OD, image_Cue_HTRF_OD, image_Cross_HTRF_OD, image_Tar_HTRF_OD, key_HTRF_OD],
                )
                HTRF_OD.status = NOT_STARTED
                continueRoutine = True
                # update component parameters for each repeat
                #--- CUSTOM START ---
                image_Tar_HTRF_OD.setPos((my_coordTDA_GL[0, my_TDAGL_counter, my_outerloopcounter], my_coordTDA_GL[1, my_TDAGL_counter, my_outerloopcounter]))
                # replaces the old line 'image_Tar_HTRF.setPos((target_xcoor, target_ycoor))'
                #--- CUSTOM END ---
                # create starting attributes for key_HTRF_OD
                key_HTRF_OD.keys = []
                key_HTRF_OD.rt = []
                _key_HTRF_OD_allKeys = []
                # store start times for HTRF_OD
                HTRF_OD.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
                HTRF_OD.tStart = globalClock.getTime(format='float')
                HTRF_OD.status = STARTED
                thisExp.addData('HTRF_OD.started', HTRF_OD.tStart)
                HTRF_OD.maxDuration = None
                # keep track of which components have finished
                HTRF_ODComponents = HTRF_OD.components
                for thisComponent in HTRF_OD.components:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "HTRF_OD" ---
                # if trial has changed, end Routine now
                if isinstance(Trials_HTRF_OD, data.TrialHandler2) and thisTrials_HTRF_OD.thisN != Trials_HTRF_OD.thisTrial.thisN:
                    continueRoutine = False
                HTRF_OD.forceEnded = routineForceEnded = not continueRoutine
                while continueRoutine and routineTimer.getTime() < 1.6:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *image1_HTRF_OD* updates
                    
                    # if image1_HTRF_OD is starting this frame...
                    if image1_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image1_HTRF_OD.frameNStart = frameN  # exact frame index
                        image1_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image1_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image1_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image1_HTRF_OD.started')
                        # update status
                        image1_HTRF_OD.status = STARTED
                        image1_HTRF_OD.setAutoDraw(True)
                    
                    # if image1_HTRF_OD is active this frame...
                    if image1_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image1_HTRF_OD is stopping this frame...
                    if image1_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image1_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image1_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image1_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image1_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image1_HTRF_OD.stopped')
                            # update status
                            image1_HTRF_OD.status = FINISHED
                            image1_HTRF_OD.setAutoDraw(False)
                    
                    # *image2_HTRF_OD* updates
                    
                    # if image2_HTRF_OD is starting this frame...
                    if image2_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.066667-frameTolerance:
                        # keep track of start time/frame for later
                        image2_HTRF_OD.frameNStart = frameN  # exact frame index
                        image2_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image2_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image2_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image2_HTRF_OD.started')
                        # update status
                        image2_HTRF_OD.status = STARTED
                        image2_HTRF_OD.setAutoDraw(True)
                    
                    # if image2_HTRF_OD is active this frame...
                    if image2_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image2_HTRF_OD is stopping this frame...
                    if image2_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image2_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image2_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image2_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image2_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image2_HTRF_OD.stopped')
                            # update status
                            image2_HTRF_OD.status = FINISHED
                            image2_HTRF_OD.setAutoDraw(False)
                    
                    # *image3_HTRF_OD* updates
                    
                    # if image3_HTRF_OD is starting this frame...
                    if image3_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.133334-frameTolerance:
                        # keep track of start time/frame for later
                        image3_HTRF_OD.frameNStart = frameN  # exact frame index
                        image3_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image3_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image3_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image3_HTRF_OD.started')
                        # update status
                        image3_HTRF_OD.status = STARTED
                        image3_HTRF_OD.setAutoDraw(True)
                    
                    # if image3_HTRF_OD is active this frame...
                    if image3_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image3_HTRF_OD is stopping this frame...
                    if image3_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image3_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image3_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image3_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image3_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image3_HTRF_OD.stopped')
                            # update status
                            image3_HTRF_OD.status = FINISHED
                            image3_HTRF_OD.setAutoDraw(False)
                    
                    # *image4_HTRF_OD* updates
                    
                    # if image4_HTRF_OD is starting this frame...
                    if image4_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.200001-frameTolerance:
                        # keep track of start time/frame for later
                        image4_HTRF_OD.frameNStart = frameN  # exact frame index
                        image4_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image4_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image4_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image4_HTRF_OD.started')
                        # update status
                        image4_HTRF_OD.status = STARTED
                        image4_HTRF_OD.setAutoDraw(True)
                    
                    # if image4_HTRF_OD is active this frame...
                    if image4_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image4_HTRF_OD is stopping this frame...
                    if image4_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image4_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image4_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image4_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image4_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image4_HTRF_OD.stopped')
                            # update status
                            image4_HTRF_OD.status = FINISHED
                            image4_HTRF_OD.setAutoDraw(False)
                    
                    # *image5_HTRF_OD* updates
                    
                    # if image5_HTRF_OD is starting this frame...
                    if image5_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.266668-frameTolerance:
                        # keep track of start time/frame for later
                        image5_HTRF_OD.frameNStart = frameN  # exact frame index
                        image5_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image5_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image5_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image5_HTRF_OD.started')
                        # update status
                        image5_HTRF_OD.status = STARTED
                        image5_HTRF_OD.setAutoDraw(True)
                    
                    # if image5_HTRF_OD is active this frame...
                    if image5_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image5_HTRF_OD is stopping this frame...
                    if image5_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image5_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image5_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image5_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image5_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image5_HTRF_OD.stopped')
                            # update status
                            image5_HTRF_OD.status = FINISHED
                            image5_HTRF_OD.setAutoDraw(False)
                    
                    # *image6_HTRF_OD* updates
                    
                    # if image6_HTRF_OD is starting this frame...
                    if image6_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.333335-frameTolerance:
                        # keep track of start time/frame for later
                        image6_HTRF_OD.frameNStart = frameN  # exact frame index
                        image6_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image6_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image6_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image6_HTRF_OD.started')
                        # update status
                        image6_HTRF_OD.status = STARTED
                        image6_HTRF_OD.setAutoDraw(True)
                    
                    # if image6_HTRF_OD is active this frame...
                    if image6_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image6_HTRF_OD is stopping this frame...
                    if image6_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image6_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image6_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image6_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image6_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image6_HTRF_OD.stopped')
                            # update status
                            image6_HTRF_OD.status = FINISHED
                            image6_HTRF_OD.setAutoDraw(False)
                    
                    # *image7_HTRF_OD* updates
                    
                    # if image7_HTRF_OD is starting this frame...
                    if image7_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.400002-frameTolerance:
                        # keep track of start time/frame for later
                        image7_HTRF_OD.frameNStart = frameN  # exact frame index
                        image7_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image7_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image7_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image7_HTRF_OD.started')
                        # update status
                        image7_HTRF_OD.status = STARTED
                        image7_HTRF_OD.setAutoDraw(True)
                    
                    # if image7_HTRF_OD is active this frame...
                    if image7_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image7_HTRF_OD is stopping this frame...
                    if image7_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image7_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image7_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image7_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image7_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image7_HTRF_OD.stopped')
                            # update status
                            image7_HTRF_OD.status = FINISHED
                            image7_HTRF_OD.setAutoDraw(False)
                    
                    # *image8_HTRF_OD* updates
                    
                    # if image8_HTRF_OD is starting this frame...
                    if image8_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.466669-frameTolerance:
                        # keep track of start time/frame for later
                        image8_HTRF_OD.frameNStart = frameN  # exact frame index
                        image8_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image8_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image8_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image8_HTRF_OD.started')
                        # update status
                        image8_HTRF_OD.status = STARTED
                        image8_HTRF_OD.setAutoDraw(True)
                    
                    # if image8_HTRF_OD is active this frame...
                    if image8_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image8_HTRF_OD is stopping this frame...
                    if image8_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image8_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image8_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image8_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image8_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image8_HTRF_OD.stopped')
                            # update status
                            image8_HTRF_OD.status = FINISHED
                            image8_HTRF_OD.setAutoDraw(False)
                    
                    # *image9_HTRF_OD* updates
                    
                    # if image9_HTRF_OD is starting this frame...
                    if image9_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.533336-frameTolerance:
                        # keep track of start time/frame for later
                        image9_HTRF_OD.frameNStart = frameN  # exact frame index
                        image9_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image9_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image9_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image9_HTRF_OD.started')
                        # update status
                        image9_HTRF_OD.status = STARTED
                        image9_HTRF_OD.setAutoDraw(True)
                    
                    # if image9_HTRF_OD is active this frame...
                    if image9_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image9_HTRF_OD is stopping this frame...
                    if image9_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image9_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image9_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image9_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image9_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image9_HTRF_OD.stopped')
                            # update status
                            image9_HTRF_OD.status = FINISHED
                            image9_HTRF_OD.setAutoDraw(False)
                    
                    # *image10_HTRF_OD* updates
                    
                    # if image10_HTRF_OD is starting this frame...
                    if image10_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.600003-frameTolerance:
                        # keep track of start time/frame for later
                        image10_HTRF_OD.frameNStart = frameN  # exact frame index
                        image10_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image10_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image10_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image10_HTRF_OD.started')
                        # update status
                        image10_HTRF_OD.status = STARTED
                        image10_HTRF_OD.setAutoDraw(True)
                    
                    # if image10_HTRF_OD is active this frame...
                    if image10_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image10_HTRF_OD is stopping this frame...
                    if image10_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image10_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image10_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image10_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image10_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image10_HTRF_OD.stopped')
                            # update status
                            image10_HTRF_OD.status = FINISHED
                            image10_HTRF_OD.setAutoDraw(False)
                    
                    # *image11_HTRF_OD* updates
                    
                    # if image11_HTRF_OD is starting this frame...
                    if image11_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.666670-frameTolerance:
                        # keep track of start time/frame for later
                        image11_HTRF_OD.frameNStart = frameN  # exact frame index
                        image11_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image11_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image11_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image11_HTRF_OD.started')
                        # update status
                        image11_HTRF_OD.status = STARTED
                        image11_HTRF_OD.setAutoDraw(True)
                    
                    # if image11_HTRF_OD is active this frame...
                    if image11_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image11_HTRF_OD is stopping this frame...
                    if image11_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image11_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image11_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image11_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image11_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image11_HTRF_OD.stopped')
                            # update status
                            image11_HTRF_OD.status = FINISHED
                            image11_HTRF_OD.setAutoDraw(False)
                    
                    # *image12_HTRF_OD* updates
                    
                    # if image12_HTRF_OD is starting this frame...
                    if image12_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.733337-frameTolerance:
                        # keep track of start time/frame for later
                        image12_HTRF_OD.frameNStart = frameN  # exact frame index
                        image12_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image12_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image12_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image12_HTRF_OD.started')
                        # update status
                        image12_HTRF_OD.status = STARTED
                        image12_HTRF_OD.setAutoDraw(True)
                    
                    # if image12_HTRF_OD is active this frame...
                    if image12_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image12_HTRF_OD is stopping this frame...
                    if image12_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image12_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image12_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image12_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image12_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image12_HTRF_OD.stopped')
                            # update status
                            image12_HTRF_OD.status = FINISHED
                            image12_HTRF_OD.setAutoDraw(False)
                    
                    # *image13_HTRF_OD* updates
                    
                    # if image13_HTRF_OD is starting this frame...
                    if image13_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.800004-frameTolerance:
                        # keep track of start time/frame for later
                        image13_HTRF_OD.frameNStart = frameN  # exact frame index
                        image13_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image13_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image13_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image13_HTRF_OD.started')
                        # update status
                        image13_HTRF_OD.status = STARTED
                        image13_HTRF_OD.setAutoDraw(True)
                    
                    # if image13_HTRF_OD is active this frame...
                    if image13_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image13_HTRF_OD is stopping this frame...
                    if image13_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image13_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image13_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image13_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image13_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image13_HTRF_OD.stopped')
                            # update status
                            image13_HTRF_OD.status = FINISHED
                            image13_HTRF_OD.setAutoDraw(False)
                    
                    # *image14_HTRF_OD* updates
                    
                    # if image14_HTRF_OD is starting this frame...
                    if image14_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.866671-frameTolerance:
                        # keep track of start time/frame for later
                        image14_HTRF_OD.frameNStart = frameN  # exact frame index
                        image14_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image14_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image14_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image14_HTRF_OD.started')
                        # update status
                        image14_HTRF_OD.status = STARTED
                        image14_HTRF_OD.setAutoDraw(True)
                    
                    # if image14_HTRF_OD is active this frame...
                    if image14_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image14_HTRF_OD is stopping this frame...
                    if image14_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image14_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image14_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image14_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image14_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image14_HTRF_OD.stopped')
                            # update status
                            image14_HTRF_OD.status = FINISHED
                            image14_HTRF_OD.setAutoDraw(False)
                    
                    # *image15_HTRF_OD* updates
                    
                    # if image15_HTRF_OD is starting this frame...
                    if image15_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.933338-frameTolerance:
                        # keep track of start time/frame for later
                        image15_HTRF_OD.frameNStart = frameN  # exact frame index
                        image15_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image15_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image15_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image15_HTRF_OD.started')
                        # update status
                        image15_HTRF_OD.status = STARTED
                        image15_HTRF_OD.setAutoDraw(True)
                    
                    # if image15_HTRF_OD is active this frame...
                    if image15_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image15_HTRF_OD is stopping this frame...
                    if image15_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image15_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image15_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image15_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image15_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image15_HTRF_OD.stopped')
                            # update status
                            image15_HTRF_OD.status = FINISHED
                            image15_HTRF_OD.setAutoDraw(False)
                    
                    # *image16_HTRF_OD* updates
                    
                    # if image16_HTRF_OD is starting this frame...
                    if image16_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.000005-frameTolerance:
                        # keep track of start time/frame for later
                        image16_HTRF_OD.frameNStart = frameN  # exact frame index
                        image16_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image16_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image16_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image16_HTRF_OD.started')
                        # update status
                        image16_HTRF_OD.status = STARTED
                        image16_HTRF_OD.setAutoDraw(True)
                    
                    # if image16_HTRF_OD is active this frame...
                    if image16_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image16_HTRF_OD is stopping this frame...
                    if image16_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image16_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image16_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image16_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image16_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image16_HTRF_OD.stopped')
                            # update status
                            image16_HTRF_OD.status = FINISHED
                            image16_HTRF_OD.setAutoDraw(False)
                    
                    # *image17_HTRF_OD* updates
                    
                    # if image17_HTRF_OD is starting this frame...
                    if image17_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.066672-frameTolerance:
                        # keep track of start time/frame for later
                        image17_HTRF_OD.frameNStart = frameN  # exact frame index
                        image17_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image17_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image17_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image17_HTRF_OD.started')
                        # update status
                        image17_HTRF_OD.status = STARTED
                        image17_HTRF_OD.setAutoDraw(True)
                    
                    # if image17_HTRF_OD is active this frame...
                    if image17_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image17_HTRF_OD is stopping this frame...
                    if image17_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image17_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image17_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image17_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image17_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image17_HTRF_OD.stopped')
                            # update status
                            image17_HTRF_OD.status = FINISHED
                            image17_HTRF_OD.setAutoDraw(False)
                    
                    # *image18_HTRF_OD* updates
                    
                    # if image18_HTRF_OD is starting this frame...
                    if image18_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.133339-frameTolerance:
                        # keep track of start time/frame for later
                        image18_HTRF_OD.frameNStart = frameN  # exact frame index
                        image18_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image18_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image18_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image18_HTRF_OD.started')
                        # update status
                        image18_HTRF_OD.status = STARTED
                        image18_HTRF_OD.setAutoDraw(True)
                    
                    # if image18_HTRF_OD is active this frame...
                    if image18_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image18_HTRF_OD is stopping this frame...
                    if image18_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image18_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image18_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image18_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image18_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image18_HTRF_OD.stopped')
                            # update status
                            image18_HTRF_OD.status = FINISHED
                            image18_HTRF_OD.setAutoDraw(False)
                    
                    # *image19_HTRF_OD* updates
                    
                    # if image19_HTRF_OD is starting this frame...
                    if image19_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.200006-frameTolerance:
                        # keep track of start time/frame for later
                        image19_HTRF_OD.frameNStart = frameN  # exact frame index
                        image19_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image19_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image19_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image19_HTRF_OD.started')
                        # update status
                        image19_HTRF_OD.status = STARTED
                        image19_HTRF_OD.setAutoDraw(True)
                    
                    # if image19_HTRF_OD is active this frame...
                    if image19_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image19_HTRF_OD is stopping this frame...
                    if image19_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image19_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image19_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image19_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image19_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image19_HTRF_OD.stopped')
                            # update status
                            image19_HTRF_OD.status = FINISHED
                            image19_HTRF_OD.setAutoDraw(False)
                    
                    # *image20_HTRF_OD* updates
                    
                    # if image20_HTRF_OD is starting this frame...
                    if image20_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.266673-frameTolerance:
                        # keep track of start time/frame for later
                        image20_HTRF_OD.frameNStart = frameN  # exact frame index
                        image20_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image20_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image20_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image20_HTRF_OD.started')
                        # update status
                        image20_HTRF_OD.status = STARTED
                        image20_HTRF_OD.setAutoDraw(True)
                    
                    # if image20_HTRF_OD is active this frame...
                    if image20_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image20_HTRF_OD is stopping this frame...
                    if image20_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image20_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image20_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image20_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image20_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image20_HTRF_OD.stopped')
                            # update status
                            image20_HTRF_OD.status = FINISHED
                            image20_HTRF_OD.setAutoDraw(False)
                    
                    # *image21_HTRF_OD* updates
                    
                    # if image21_HTRF_OD is starting this frame...
                    if image21_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.333340-frameTolerance:
                        # keep track of start time/frame for later
                        image21_HTRF_OD.frameNStart = frameN  # exact frame index
                        image21_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image21_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image21_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image21_HTRF_OD.started')
                        # update status
                        image21_HTRF_OD.status = STARTED
                        image21_HTRF_OD.setAutoDraw(True)
                    
                    # if image21_HTRF_OD is active this frame...
                    if image21_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image21_HTRF_OD is stopping this frame...
                    if image21_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image21_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image21_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image21_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image21_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image21_HTRF_OD.stopped')
                            # update status
                            image21_HTRF_OD.status = FINISHED
                            image21_HTRF_OD.setAutoDraw(False)
                    
                    # *image22_HTRF_OD* updates
                    
                    # if image22_HTRF_OD is starting this frame...
                    if image22_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.400007-frameTolerance:
                        # keep track of start time/frame for later
                        image22_HTRF_OD.frameNStart = frameN  # exact frame index
                        image22_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image22_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image22_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image22_HTRF_OD.started')
                        # update status
                        image22_HTRF_OD.status = STARTED
                        image22_HTRF_OD.setAutoDraw(True)
                    
                    # if image22_HTRF_OD is active this frame...
                    if image22_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image22_HTRF_OD is stopping this frame...
                    if image22_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image22_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image22_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image22_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image22_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image22_HTRF_OD.stopped')
                            # update status
                            image22_HTRF_OD.status = FINISHED
                            image22_HTRF_OD.setAutoDraw(False)
                    
                    # *image23_HTRF_OD* updates
                    
                    # if image23_HTRF_OD is starting this frame...
                    if image23_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.466674-frameTolerance:
                        # keep track of start time/frame for later
                        image23_HTRF_OD.frameNStart = frameN  # exact frame index
                        image23_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image23_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image23_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image23_HTRF_OD.started')
                        # update status
                        image23_HTRF_OD.status = STARTED
                        image23_HTRF_OD.setAutoDraw(True)
                    
                    # if image23_HTRF_OD is active this frame...
                    if image23_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image23_HTRF_OD is stopping this frame...
                    if image23_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image23_HTRF_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image23_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image23_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image23_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image23_HTRF_OD.stopped')
                            # update status
                            image23_HTRF_OD.status = FINISHED
                            image23_HTRF_OD.setAutoDraw(False)
                    
                    # *image24_HTRF_OD* updates
                    
                    # if image24_HTRF_OD is starting this frame...
                    if image24_HTRF_OD.status == NOT_STARTED and tThisFlip >= 1.533341-frameTolerance:
                        # keep track of start time/frame for later
                        image24_HTRF_OD.frameNStart = frameN  # exact frame index
                        image24_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image24_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image24_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image24_HTRF_OD.started')
                        # update status
                        image24_HTRF_OD.status = STARTED
                        image24_HTRF_OD.setAutoDraw(True)
                    
                    # if image24_HTRF_OD is active this frame...
                    if image24_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image24_HTRF_OD is stopping this frame...
                    if image24_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image24_HTRF_OD.tStartRefresh + 0.066659-frameTolerance:
                            # keep track of stop time/frame for later
                            image24_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image24_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image24_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image24_HTRF_OD.stopped')
                            # update status
                            image24_HTRF_OD.status = FINISHED
                            image24_HTRF_OD.setAutoDraw(False)
                    
                    # *image_Frame_HTRF_OD* updates
                    
                    # if image_Frame_HTRF_OD is starting this frame...
                    if image_Frame_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Frame_HTRF_OD.frameNStart = frameN  # exact frame index
                        image_Frame_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image_Frame_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Frame_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Frame_HTRF_OD.started')
                        # update status
                        image_Frame_HTRF_OD.status = STARTED
                        image_Frame_HTRF_OD.setAutoDraw(True)
                    
                    # if image_Frame_HTRF_OD is active this frame...
                    if image_Frame_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Frame_HTRF_OD is stopping this frame...
                    if image_Frame_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Frame_HTRF_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Frame_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image_Frame_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Frame_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Frame_HTRF_OD.stopped')
                            # update status
                            image_Frame_HTRF_OD.status = FINISHED
                            image_Frame_HTRF_OD.setAutoDraw(False)
                    
                    # *image_Cue_HTRF_OD* updates
                    
                    # if image_Cue_HTRF_OD is starting this frame...
                    if image_Cue_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Cue_HTRF_OD.frameNStart = frameN  # exact frame index
                        image_Cue_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image_Cue_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Cue_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cue_HTRF_OD.started')
                        # update status
                        image_Cue_HTRF_OD.status = STARTED
                        image_Cue_HTRF_OD.setAutoDraw(True)
                    
                    # if image_Cue_HTRF_OD is active this frame...
                    if image_Cue_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Cue_HTRF_OD is stopping this frame...
                    if image_Cue_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Cue_HTRF_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Cue_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image_Cue_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Cue_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Cue_HTRF_OD.stopped')
                            # update status
                            image_Cue_HTRF_OD.status = FINISHED
                            image_Cue_HTRF_OD.setAutoDraw(False)
                    
                    # *image_Cross_HTRF_OD* updates
                    
                    # if image_Cross_HTRF_OD is starting this frame...
                    if image_Cross_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Cross_HTRF_OD.frameNStart = frameN  # exact frame index
                        image_Cross_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image_Cross_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Cross_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cross_HTRF_OD.started')
                        # update status
                        image_Cross_HTRF_OD.status = STARTED
                        image_Cross_HTRF_OD.setAutoDraw(True)
                    
                    # if image_Cross_HTRF_OD is active this frame...
                    if image_Cross_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Cross_HTRF_OD is stopping this frame...
                    if image_Cross_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Cross_HTRF_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Cross_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image_Cross_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Cross_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Cross_HTRF_OD.stopped')
                            # update status
                            image_Cross_HTRF_OD.status = FINISHED
                            image_Cross_HTRF_OD.setAutoDraw(False)
                    
                    # *image_Tar_HTRF_OD* updates
                    
                    # if image_Tar_HTRF_OD is starting this frame...
                    if image_Tar_HTRF_OD.status == NOT_STARTED and tThisFlip >= (1.6 - my_randtartime[my_randtartime_counter])-frameTolerance:   ### CUSTOM START AND END 
                        # keep track of start time/frame for later
                        image_Tar_HTRF_OD.frameNStart = frameN  # exact frame index
                        image_Tar_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        image_Tar_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Tar_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Tar_HTRF_OD.started')
                        # update status
                        image_Tar_HTRF_OD.status = STARTED
                        image_Tar_HTRF_OD.setAutoDraw(True)
                    
                    # if image_Tar_HTRF_OD is active this frame...
                    if image_Tar_HTRF_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Tar_HTRF_OD is stopping this frame...
                    if image_Tar_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Tar_HTRF_OD.tStartRefresh + my_randtartime[my_randtartime_counter]-frameTolerance:         ### CUSTOM START AND END 
                            # keep track of stop time/frame for later
                            image_Tar_HTRF_OD.tStop = t  # not accounting for scr refresh
                            image_Tar_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Tar_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Tar_HTRF_OD.stopped')
                            # update status
                            image_Tar_HTRF_OD.status = FINISHED
                            image_Tar_HTRF_OD.setAutoDraw(False)
                    
                    # *key_HTRF_OD* updates
                    waitOnFlip = False
                    
                    # if key_HTRF_OD is starting this frame...
                    if key_HTRF_OD.status == NOT_STARTED and tThisFlip >= 0.1-frameTolerance:
                        # keep track of start time/frame for later
                        key_HTRF_OD.frameNStart = frameN  # exact frame index
                        key_HTRF_OD.tStart = t  # local t and not account for scr refresh
                        key_HTRF_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(key_HTRF_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'key_HTRF_OD.started')
                        # update status
                        key_HTRF_OD.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(key_HTRF_OD.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(key_HTRF_OD.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    
                    # if key_HTRF_OD is stopping this frame...
                    if key_HTRF_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > key_HTRF_OD.tStartRefresh + 1.5-frameTolerance:
                            # keep track of stop time/frame for later
                            key_HTRF_OD.tStop = t  # not accounting for scr refresh
                            key_HTRF_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            key_HTRF_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'key_HTRF_OD.stopped')
                            # update status
                            key_HTRF_OD.status = FINISHED
                            key_HTRF_OD.status = FINISHED
                    if key_HTRF_OD.status == STARTED and not waitOnFlip:
                        theseKeys = key_HTRF_OD.getKeys(keyList=['1'], ignoreKeys=["escape"], waitRelease=False)
                        _key_HTRF_OD_allKeys.extend(theseKeys)
                        if len(_key_HTRF_OD_allKeys):
                            key_HTRF_OD.keys = _key_HTRF_OD_allKeys[0].name  # just the first key pressed
                            key_HTRF_OD.rt = _key_HTRF_OD_allKeys[0].rt
                            key_HTRF_OD.duration = _key_HTRF_OD_allKeys[0].duration
                            # was this correct?
                            ### CUSTOM START 
                            if (key_HTRF_OD.keys == str(my_corrResp_GL[my_outerloopcounter][my_TDAGL_counter])) or (key_HTRF_OD.keys == my_corrResp_GL[my_outerloopcounter][my_TDAGL_counter]):
                            #if (key_HTRF.keys == str(corr_resp)) or (key_HTRF.keys == corr_resp):
                                key_HTRF_OD.corr = 1
                            else:
                                key_HTRF_OD.corr = 0
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, win=win)
                        return
                    # pause experiment here if requested
                    if thisExp.status == PAUSED:
                        pauseExperiment(
                            thisExp=thisExp, 
                            win=win, 
                            timers=[routineTimer], 
                            playbackComponents=[]
                        )
                        # skip the frame we paused on
                        continue
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        HTRF_OD.forceEnded = routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in HTRF_OD.components:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                my_randtartime_counter = my_randtartime_counter + 1          ### CUSTOM START AND END
                
                # --- Ending Routine "HTRF_OD" ---
                for thisComponent in HTRF_OD.components:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                # store stop times for HTRF_OD
                HTRF_OD.tStop = globalClock.getTime(format='float')
                HTRF_OD.tStopRefresh = tThisFlipGlobal
                thisExp.addData('HTRF_OD.stopped', HTRF_OD.tStop)
                # check responses
                if key_HTRF_OD.keys in ['', [], None]:  # No response was made
                    key_HTRF_OD.keys = None
                    # was no response the correct answer?!
                    if str(my_corrResp_GL[my_outerloopcounter][my_TDAGL_counter]).lower() == 'none': ## CUSTOM START & END
                       key_HTRF_OD.corr = 1;  # correct non-response
                    else:
                       key_HTRF_OD.corr = 0;  # failed to respond (incorrectly)
                # store data for Trials_HTRF_OD (TrialHandler)
                Trials_HTRF_OD.addData('key_HTRF_OD.keys',key_HTRF_OD.keys)
                Trials_HTRF_OD.addData('key_HTRF_OD.corr', key_HTRF_OD.corr)
                if key_HTRF_OD.keys != None:  # we had a response
                    Trials_HTRF_OD.addData('key_HTRF_OD.rt', key_HTRF_OD.rt)
                    Trials_HTRF_OD.addData('key_HTRF_OD.duration', key_HTRF_OD.duration)
                try:
                    if image1_HTRF_OD.tStopRefresh is not None:
                        duration_val = image1_HTRF_OD.tStopRefresh - image1_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image1_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image1_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image1_HTRF_OD).__name__,
                        trial_type='image1_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image1_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image2_HTRF_OD.tStopRefresh is not None:
                        duration_val = image2_HTRF_OD.tStopRefresh - image2_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image2_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image2_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image2_HTRF_OD).__name__,
                        trial_type='image2_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image2_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image3_HTRF_OD.tStopRefresh is not None:
                        duration_val = image3_HTRF_OD.tStopRefresh - image3_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image3_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image3_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image3_HTRF_OD).__name__,
                        trial_type='image3_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image3_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image4_HTRF_OD.tStopRefresh is not None:
                        duration_val = image4_HTRF_OD.tStopRefresh - image4_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image4_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image4_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image4_HTRF_OD).__name__,
                        trial_type='image4_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image4_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image5_HTRF_OD.tStopRefresh is not None:
                        duration_val = image5_HTRF_OD.tStopRefresh - image5_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image5_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image5_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image5_HTRF_OD).__name__,
                        trial_type='image5_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image5_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image6_HTRF_OD.tStopRefresh is not None:
                        duration_val = image6_HTRF_OD.tStopRefresh - image6_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image6_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image6_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image6_HTRF_OD).__name__,
                        trial_type='image6_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image6_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image7_HTRF_OD.tStopRefresh is not None:
                        duration_val = image7_HTRF_OD.tStopRefresh - image7_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image7_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image7_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image7_HTRF_OD).__name__,
                        trial_type='image7_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image7_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image8_HTRF_OD.tStopRefresh is not None:
                        duration_val = image8_HTRF_OD.tStopRefresh - image8_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image8_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image8_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image8_HTRF_OD).__name__,
                        trial_type='image8_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image8_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image9_HTRF_OD.tStopRefresh is not None:
                        duration_val = image9_HTRF_OD.tStopRefresh - image9_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image9_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image9_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image9_HTRF_OD).__name__,
                        trial_type='image9_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image9_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image10_HTRF_OD.tStopRefresh is not None:
                        duration_val = image10_HTRF_OD.tStopRefresh - image10_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image10_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image10_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image10_HTRF_OD).__name__,
                        trial_type='image10_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image10_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image11_HTRF_OD.tStopRefresh is not None:
                        duration_val = image11_HTRF_OD.tStopRefresh - image11_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image11_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image11_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image11_HTRF_OD).__name__,
                        trial_type='image11_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image11_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image12_HTRF_OD.tStopRefresh is not None:
                        duration_val = image12_HTRF_OD.tStopRefresh - image12_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image12_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image12_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image12_HTRF_OD).__name__,
                        trial_type='image12_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image12_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image13_HTRF_OD.tStopRefresh is not None:
                        duration_val = image13_HTRF_OD.tStopRefresh - image13_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image13_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image13_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image13_HTRF_OD).__name__,
                        trial_type='image13_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image13_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image14_HTRF_OD.tStopRefresh is not None:
                        duration_val = image14_HTRF_OD.tStopRefresh - image14_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image14_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image14_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image14_HTRF_OD).__name__,
                        trial_type='image14_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image14_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image15_HTRF_OD.tStopRefresh is not None:
                        duration_val = image15_HTRF_OD.tStopRefresh - image15_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image15_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image15_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image15_HTRF_OD).__name__,
                        trial_type='image15_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image15_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image16_HTRF_OD.tStopRefresh is not None:
                        duration_val = image16_HTRF_OD.tStopRefresh - image16_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image16_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image16_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image16_HTRF_OD).__name__,
                        trial_type='image16_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image16_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image17_HTRF_OD.tStopRefresh is not None:
                        duration_val = image17_HTRF_OD.tStopRefresh - image17_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image17_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image17_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image17_HTRF_OD).__name__,
                        trial_type='image17_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image17_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image18_HTRF_OD.tStopRefresh is not None:
                        duration_val = image18_HTRF_OD.tStopRefresh - image18_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image18_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image18_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image18_HTRF_OD).__name__,
                        trial_type='image18_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image18_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image19_HTRF_OD.tStopRefresh is not None:
                        duration_val = image19_HTRF_OD.tStopRefresh - image19_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image19_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image19_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image19_HTRF_OD).__name__,
                        trial_type='image19_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image19_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image20_HTRF_OD.tStopRefresh is not None:
                        duration_val = image20_HTRF_OD.tStopRefresh - image20_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image20_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image20_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image20_HTRF_OD).__name__,
                        trial_type='image20_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image20_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image21_HTRF_OD.tStopRefresh is not None:
                        duration_val = image21_HTRF_OD.tStopRefresh - image21_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image21_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image21_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image21_HTRF_OD).__name__,
                        trial_type='image21_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image21_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image22_HTRF_OD.tStopRefresh is not None:
                        duration_val = image22_HTRF_OD.tStopRefresh - image22_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image22_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image22_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image22_HTRF_OD).__name__,
                        trial_type='image22_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image22_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image23_HTRF_OD.tStopRefresh is not None:
                        duration_val = image23_HTRF_OD.tStopRefresh - image23_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image23_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image23_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image23_HTRF_OD).__name__,
                        trial_type='image23_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image23_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image24_HTRF_OD.tStopRefresh is not None:
                        duration_val = image24_HTRF_OD.tStopRefresh - image24_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image24_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image24_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image24_HTRF_OD).__name__,
                        trial_type='image24_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image24_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image_Cue_HTRF_OD.tStopRefresh is not None:
                        duration_val = image_Cue_HTRF_OD.tStopRefresh - image_Cue_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image_Cue_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image_Cue_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image_Cue_HTRF_OD).__name__,
                        trial_type='image_Cue_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image_Cue_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image_Tar_HTRF_OD.tStopRefresh is not None:
                        duration_val = image_Tar_HTRF_OD.tStopRefresh - image_Tar_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - image_Tar_HTRF_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image_Tar_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image_Tar_HTRF_OD).__name__,
                        trial_type='image_Tar_HTRF_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_image_Tar_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if key_HTRF_OD.tStopRefresh is not None:
                        duration_val = key_HTRF_OD.tStopRefresh - key_HTRF_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRF_OD.stopped'] - key_HTRF_OD.tStartRefresh
                    if hasattr(key_HTRF_OD, 'rt'):
                        rt_val = key_HTRF_OD.rt
                    else:
                        rt_val = None
                        logging.warning('The linked component "key_HTRF_OD" does not have a reaction time(.rt) attribute. Unable to link BIDS response_time to this component. Please verify the component settings.')
                    bids_event = BIDSTaskEvent(
                        onset=key_HTRF_OD.tStartRefresh,
                        duration=duration_val,
                        response_time=rt_val,
                        event_type=type(key_HTRF_OD).__name__,
                        trial_type='key_HTRF_OD',
                        value=key_HTRF_OD.corr,
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRF_OD.addData('bidsEvent_key_HTRF_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
                if HTRF_OD.maxDurationReached:
                    routineTimer.addTime(-HTRF_OD.maxDuration)
                elif HTRF_OD.forceEnded:
                    routineTimer.reset()
                else:
                    routineTimer.addTime(-1.600000)
                thisExp.nextEntry()
                
                ## CUSTOM START
                my_TDAGL_counter = my_TDAGL_counter + 1
                ## CUSTOM END
                
            # completed 1.0 repeats of 'Trials_HTRF_OD'
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            # get names of stimulus parameters
            if Trials_HTRF_OD.trialList in ([], [None], None):
                params = []
            else:
                params = Trials_HTRF_OD.trialList[0].keys()
            # save data for this loop
            Trials_HTRF_OD.saveAsExcel(filename + '.xlsx', sheetName='Trials_HTRF_OD',
                stimOut=params,
                dataOut=['n','all_mean','all_std', 'all_raw'])
            Trials_HTRF_OD.saveAsText(filename + 'Trials_HTRF_OD.csv', delim=',',
                stimOut=params,
                dataOut=['n','all_mean','all_std', 'all_raw'])
            
            # --- Prepare to start Routine "Break" ---
            # create an object to store info about Routine Break
            Break = data.Routine(
                name='Break',
                components=[image_Frame_Break, image_Cross_Break],
            )
            Break.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            # store start times for Break
            Break.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            Break.tStart = globalClock.getTime(format='float')
            Break.status = STARTED
            thisExp.addData('Break.started', Break.tStart)
            Break.maxDuration = None
            # keep track of which components have finished
            BreakComponents = Break.components
            for thisComponent in Break.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "Break" ---
            # if trial has changed, end Routine now
            if isinstance(Outerloop, data.TrialHandler2) and thisOuterloop.thisN != Outerloop.thisTrial.thisN:
                continueRoutine = False
            Break.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 1.0:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *image_Frame_Break* updates
                
                # if image_Frame_Break is starting this frame...
                if image_Frame_Break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    image_Frame_Break.frameNStart = frameN  # exact frame index
                    image_Frame_Break.tStart = t  # local t and not account for scr refresh
                    image_Frame_Break.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_Frame_Break, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_Frame_Break.started')
                    # update status
                    image_Frame_Break.status = STARTED
                    image_Frame_Break.setAutoDraw(True)
                
                # if image_Frame_Break is active this frame...
                if image_Frame_Break.status == STARTED:
                    # update params
                    pass
                
                # if image_Frame_Break is stopping this frame...
                if image_Frame_Break.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_Frame_Break.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        image_Frame_Break.tStop = t  # not accounting for scr refresh
                        image_Frame_Break.tStopRefresh = tThisFlipGlobal  # on global time
                        image_Frame_Break.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Frame_Break.stopped')
                        # update status
                        image_Frame_Break.status = FINISHED
                        image_Frame_Break.setAutoDraw(False)
                
                # *image_Cross_Break* updates
                
                # if image_Cross_Break is starting this frame...
                if image_Cross_Break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    image_Cross_Break.frameNStart = frameN  # exact frame index
                    image_Cross_Break.tStart = t  # local t and not account for scr refresh
                    image_Cross_Break.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_Cross_Break, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_Cross_Break.started')
                    # update status
                    image_Cross_Break.status = STARTED
                    image_Cross_Break.setAutoDraw(True)
                
                # if image_Cross_Break is active this frame...
                if image_Cross_Break.status == STARTED:
                    # update params
                    pass
                
                # if image_Cross_Break is stopping this frame...
                if image_Cross_Break.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_Cross_Break.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        image_Cross_Break.tStop = t  # not accounting for scr refresh
                        image_Cross_Break.tStopRefresh = tThisFlipGlobal  # on global time
                        image_Cross_Break.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cross_Break.stopped')
                        # update status
                        image_Cross_Break.status = FINISHED
                        image_Cross_Break.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer], 
                        playbackComponents=[]
                    )
                    # skip the frame we paused on
                    continue
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    Break.forceEnded = routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in Break.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "Break" ---
            for thisComponent in Break.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for Break
            Break.tStop = globalClock.getTime(format='float')
            Break.tStopRefresh = tThisFlipGlobal
            thisExp.addData('Break.stopped', Break.tStop)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if Break.maxDurationReached:
                routineTimer.addTime(-Break.maxDuration)
            elif Break.forceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.000000)
            
        #Custom-Comment: End TDA_GL
        elif my_seq_num[my_outerloopcounter]==4:
        #Custom-Comment: Start TDA_GR
        
            # set up handler to look after randomisation of conditions etc
            Trials_HTRU_OD = data.TrialHandler2(
                name='Trials_HTRU_OD',
                nReps=1.0, 
                method='random', 
                extraInfo=expInfo, 
                originPath=-1, 
                trialList=data.importConditions('Conditions_TL_ND.xlsx'), 
                seed=None, 
            )
            thisExp.addLoop(Trials_HTRU_OD)  # add the loop to the experiment
            thisTrials_HTRU_OD = Trials_HTRU_OD.trialList[0]  # so we can initialise stimuli with some values
            # abbreviate parameter names if possible (e.g. rgb = thisTrials_HTRU_OD.rgb)
            if thisTrials_HTRU_OD != None:
                for paramName in thisTrials_HTRU_OD:
                    globals()[paramName] = thisTrials_HTRU_OD[paramName]
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            
            #--- CUSTOM START ---
            my_TDAGR_counter = 0
            #--- CUSTOM END ---
            
            for thisTrials_HTRU_OD in Trials_HTRU_OD:
                currentLoop = Trials_HTRU_OD
                thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
                if thisSession is not None:
                    # if running in a Session with a Liaison client, send data up to now
                    thisSession.sendExperimentData()
                # abbreviate parameter names if possible (e.g. rgb = thisTrials_HTRU_OD.rgb)
                if thisTrials_HTRU_OD != None:
                    for paramName in thisTrials_HTRU_OD:
                        globals()[paramName] = thisTrials_HTRU_OD[paramName]
                
                # --- Prepare to start Routine "HTRU_OD" ---
                # create an object to store info about Routine HTRU_OD
                HTRU_OD = data.Routine(
                    name='HTRU_OD',
                    components=[image1_HTRU_OD, image2_HTRU_OD, image3_HTRU_OD, image4_HTRU_OD, image5_HTRU_OD, image6_HTRU_OD, image7_HTRU_OD, image8_HTRU_OD, image9_HTRU_OD, image10_HTRU_OD, image11_HTRU_OD, image12_HTRU_OD, image13_HTRU_OD, image14_HTRU_OD, image15_HTRU_OD, image16_HTRU_OD, image17_HTRU_OD, image18_HTRU_OD, image19_HTRU_OD, image20_HTRU_OD, image21_HTRU_OD, image22_HTRU_OD, image23_HTRU_OD, image24_HTRU_OD, image_Frame_HTRU_OD, image_Cue_HTRU_OD, image_Cross_HTRU_OD, image_Tar_HTRU_OD, key_HTRU_OD],
                )
                HTRU_OD.status = NOT_STARTED
                continueRoutine = True
                # update component parameters for each repeat
                #--- CUSTOM START ---
                image_Tar_HTRU_OD.setPos((my_coordTDA_GR[0, my_TDAGR_counter, my_outerloopcounter], my_coordTDA_GR[1, my_TDAGR_counter, my_outerloopcounter]))
                # replaces the old line 'image_Tar_HTRU.setPos((target_xcoor, target_ycoor))'
                #--- CUSTOM END ---
                # create starting attributes for key_HTRU_OD
                key_HTRU_OD.keys = []
                key_HTRU_OD.rt = []
                _key_HTRU_OD_allKeys = []
                # store start times for HTRU_OD
                HTRU_OD.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
                HTRU_OD.tStart = globalClock.getTime(format='float')
                HTRU_OD.status = STARTED
                thisExp.addData('HTRU_OD.started', HTRU_OD.tStart)
                HTRU_OD.maxDuration = None
                # keep track of which components have finished
                HTRU_ODComponents = HTRU_OD.components
                for thisComponent in HTRU_OD.components:
                    thisComponent.tStart = None
                    thisComponent.tStop = None
                    thisComponent.tStartRefresh = None
                    thisComponent.tStopRefresh = None
                    if hasattr(thisComponent, 'status'):
                        thisComponent.status = NOT_STARTED
                # reset timers
                t = 0
                _timeToFirstFrame = win.getFutureFlipTime(clock="now")
                frameN = -1
                
                # --- Run Routine "HTRU_OD" ---
                # if trial has changed, end Routine now
                if isinstance(Trials_HTRU_OD, data.TrialHandler2) and thisTrials_HTRU_OD.thisN != Trials_HTRU_OD.thisTrial.thisN:
                    continueRoutine = False
                HTRU_OD.forceEnded = routineForceEnded = not continueRoutine
                while continueRoutine and routineTimer.getTime() < 1.6:
                    # get current time
                    t = routineTimer.getTime()
                    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                    # update/draw components on each frame
                    
                    # *image1_HTRU_OD* updates
                    
                    # if image1_HTRU_OD is starting this frame...
                    if image1_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image1_HTRU_OD.frameNStart = frameN  # exact frame index
                        image1_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image1_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image1_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image1_HTRU_OD.started')
                        # update status
                        image1_HTRU_OD.status = STARTED
                        image1_HTRU_OD.setAutoDraw(True)
                    
                    # if image1_HTRU_OD is active this frame...
                    if image1_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image1_HTRU_OD is stopping this frame...
                    if image1_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image1_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image1_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image1_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image1_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image1_HTRU_OD.stopped')
                            # update status
                            image1_HTRU_OD.status = FINISHED
                            image1_HTRU_OD.setAutoDraw(False)
                    
                    # *image2_HTRU_OD* updates
                    
                    # if image2_HTRU_OD is starting this frame...
                    if image2_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.066667-frameTolerance:
                        # keep track of start time/frame for later
                        image2_HTRU_OD.frameNStart = frameN  # exact frame index
                        image2_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image2_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image2_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image2_HTRU_OD.started')
                        # update status
                        image2_HTRU_OD.status = STARTED
                        image2_HTRU_OD.setAutoDraw(True)
                    
                    # if image2_HTRU_OD is active this frame...
                    if image2_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image2_HTRU_OD is stopping this frame...
                    if image2_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image2_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image2_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image2_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image2_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image2_HTRU_OD.stopped')
                            # update status
                            image2_HTRU_OD.status = FINISHED
                            image2_HTRU_OD.setAutoDraw(False)
                    
                    # *image3_HTRU_OD* updates
                    
                    # if image3_HTRU_OD is starting this frame...
                    if image3_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.133334-frameTolerance:
                        # keep track of start time/frame for later
                        image3_HTRU_OD.frameNStart = frameN  # exact frame index
                        image3_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image3_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image3_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image3_HTRU_OD.started')
                        # update status
                        image3_HTRU_OD.status = STARTED
                        image3_HTRU_OD.setAutoDraw(True)
                    
                    # if image3_HTRU_OD is active this frame...
                    if image3_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image3_HTRU_OD is stopping this frame...
                    if image3_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image3_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image3_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image3_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image3_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image3_HTRU_OD.stopped')
                            # update status
                            image3_HTRU_OD.status = FINISHED
                            image3_HTRU_OD.setAutoDraw(False)
                    
                    # *image4_HTRU_OD* updates
                    
                    # if image4_HTRU_OD is starting this frame...
                    if image4_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.200001-frameTolerance:
                        # keep track of start time/frame for later
                        image4_HTRU_OD.frameNStart = frameN  # exact frame index
                        image4_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image4_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image4_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image4_HTRU_OD.started')
                        # update status
                        image4_HTRU_OD.status = STARTED
                        image4_HTRU_OD.setAutoDraw(True)
                    
                    # if image4_HTRU_OD is active this frame...
                    if image4_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image4_HTRU_OD is stopping this frame...
                    if image4_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image4_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image4_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image4_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image4_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image4_HTRU_OD.stopped')
                            # update status
                            image4_HTRU_OD.status = FINISHED
                            image4_HTRU_OD.setAutoDraw(False)
                    
                    # *image5_HTRU_OD* updates
                    
                    # if image5_HTRU_OD is starting this frame...
                    if image5_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.266668-frameTolerance:
                        # keep track of start time/frame for later
                        image5_HTRU_OD.frameNStart = frameN  # exact frame index
                        image5_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image5_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image5_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image5_HTRU_OD.started')
                        # update status
                        image5_HTRU_OD.status = STARTED
                        image5_HTRU_OD.setAutoDraw(True)
                    
                    # if image5_HTRU_OD is active this frame...
                    if image5_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image5_HTRU_OD is stopping this frame...
                    if image5_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image5_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image5_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image5_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image5_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image5_HTRU_OD.stopped')
                            # update status
                            image5_HTRU_OD.status = FINISHED
                            image5_HTRU_OD.setAutoDraw(False)
                    
                    # *image6_HTRU_OD* updates
                    
                    # if image6_HTRU_OD is starting this frame...
                    if image6_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.333335-frameTolerance:
                        # keep track of start time/frame for later
                        image6_HTRU_OD.frameNStart = frameN  # exact frame index
                        image6_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image6_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image6_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image6_HTRU_OD.started')
                        # update status
                        image6_HTRU_OD.status = STARTED
                        image6_HTRU_OD.setAutoDraw(True)
                    
                    # if image6_HTRU_OD is active this frame...
                    if image6_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image6_HTRU_OD is stopping this frame...
                    if image6_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image6_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image6_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image6_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image6_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image6_HTRU_OD.stopped')
                            # update status
                            image6_HTRU_OD.status = FINISHED
                            image6_HTRU_OD.setAutoDraw(False)
                    
                    # *image7_HTRU_OD* updates
                    
                    # if image7_HTRU_OD is starting this frame...
                    if image7_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.400002-frameTolerance:
                        # keep track of start time/frame for later
                        image7_HTRU_OD.frameNStart = frameN  # exact frame index
                        image7_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image7_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image7_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image7_HTRU_OD.started')
                        # update status
                        image7_HTRU_OD.status = STARTED
                        image7_HTRU_OD.setAutoDraw(True)
                    
                    # if image7_HTRU_OD is active this frame...
                    if image7_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image7_HTRU_OD is stopping this frame...
                    if image7_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image7_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image7_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image7_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image7_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image7_HTRU_OD.stopped')
                            # update status
                            image7_HTRU_OD.status = FINISHED
                            image7_HTRU_OD.setAutoDraw(False)
                    
                    # *image8_HTRU_OD* updates
                    
                    # if image8_HTRU_OD is starting this frame...
                    if image8_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.466669-frameTolerance:
                        # keep track of start time/frame for later
                        image8_HTRU_OD.frameNStart = frameN  # exact frame index
                        image8_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image8_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image8_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image8_HTRU_OD.started')
                        # update status
                        image8_HTRU_OD.status = STARTED
                        image8_HTRU_OD.setAutoDraw(True)
                    
                    # if image8_HTRU_OD is active this frame...
                    if image8_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image8_HTRU_OD is stopping this frame...
                    if image8_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image8_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image8_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image8_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image8_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image8_HTRU_OD.stopped')
                            # update status
                            image8_HTRU_OD.status = FINISHED
                            image8_HTRU_OD.setAutoDraw(False)
                    
                    # *image9_HTRU_OD* updates
                    
                    # if image9_HTRU_OD is starting this frame...
                    if image9_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.533336-frameTolerance:
                        # keep track of start time/frame for later
                        image9_HTRU_OD.frameNStart = frameN  # exact frame index
                        image9_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image9_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image9_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image9_HTRU_OD.started')
                        # update status
                        image9_HTRU_OD.status = STARTED
                        image9_HTRU_OD.setAutoDraw(True)
                    
                    # if image9_HTRU_OD is active this frame...
                    if image9_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image9_HTRU_OD is stopping this frame...
                    if image9_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image9_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image9_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image9_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image9_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image9_HTRU_OD.stopped')
                            # update status
                            image9_HTRU_OD.status = FINISHED
                            image9_HTRU_OD.setAutoDraw(False)
                    
                    # *image10_HTRU_OD* updates
                    
                    # if image10_HTRU_OD is starting this frame...
                    if image10_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.600003-frameTolerance:
                        # keep track of start time/frame for later
                        image10_HTRU_OD.frameNStart = frameN  # exact frame index
                        image10_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image10_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image10_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image10_HTRU_OD.started')
                        # update status
                        image10_HTRU_OD.status = STARTED
                        image10_HTRU_OD.setAutoDraw(True)
                    
                    # if image10_HTRU_OD is active this frame...
                    if image10_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image10_HTRU_OD is stopping this frame...
                    if image10_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image10_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image10_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image10_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image10_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image10_HTRU_OD.stopped')
                            # update status
                            image10_HTRU_OD.status = FINISHED
                            image10_HTRU_OD.setAutoDraw(False)
                    
                    # *image11_HTRU_OD* updates
                    
                    # if image11_HTRU_OD is starting this frame...
                    if image11_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.666670-frameTolerance:
                        # keep track of start time/frame for later
                        image11_HTRU_OD.frameNStart = frameN  # exact frame index
                        image11_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image11_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image11_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image11_HTRU_OD.started')
                        # update status
                        image11_HTRU_OD.status = STARTED
                        image11_HTRU_OD.setAutoDraw(True)
                    
                    # if image11_HTRU_OD is active this frame...
                    if image11_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image11_HTRU_OD is stopping this frame...
                    if image11_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image11_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image11_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image11_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image11_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image11_HTRU_OD.stopped')
                            # update status
                            image11_HTRU_OD.status = FINISHED
                            image11_HTRU_OD.setAutoDraw(False)
                    
                    # *image12_HTRU_OD* updates
                    
                    # if image12_HTRU_OD is starting this frame...
                    if image12_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.733337-frameTolerance:
                        # keep track of start time/frame for later
                        image12_HTRU_OD.frameNStart = frameN  # exact frame index
                        image12_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image12_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image12_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image12_HTRU_OD.started')
                        # update status
                        image12_HTRU_OD.status = STARTED
                        image12_HTRU_OD.setAutoDraw(True)
                    
                    # if image12_HTRU_OD is active this frame...
                    if image12_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image12_HTRU_OD is stopping this frame...
                    if image12_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image12_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image12_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image12_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image12_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image12_HTRU_OD.stopped')
                            # update status
                            image12_HTRU_OD.status = FINISHED
                            image12_HTRU_OD.setAutoDraw(False)
                    
                    # *image13_HTRU_OD* updates
                    
                    # if image13_HTRU_OD is starting this frame...
                    if image13_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.800004-frameTolerance:
                        # keep track of start time/frame for later
                        image13_HTRU_OD.frameNStart = frameN  # exact frame index
                        image13_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image13_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image13_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image13_HTRU_OD.started')
                        # update status
                        image13_HTRU_OD.status = STARTED
                        image13_HTRU_OD.setAutoDraw(True)
                    
                    # if image13_HTRU_OD is active this frame...
                    if image13_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image13_HTRU_OD is stopping this frame...
                    if image13_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image13_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image13_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image13_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image13_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image13_HTRU_OD.stopped')
                            # update status
                            image13_HTRU_OD.status = FINISHED
                            image13_HTRU_OD.setAutoDraw(False)
                    
                    # *image14_HTRU_OD* updates
                    
                    # if image14_HTRU_OD is starting this frame...
                    if image14_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.866671-frameTolerance:
                        # keep track of start time/frame for later
                        image14_HTRU_OD.frameNStart = frameN  # exact frame index
                        image14_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image14_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image14_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image14_HTRU_OD.started')
                        # update status
                        image14_HTRU_OD.status = STARTED
                        image14_HTRU_OD.setAutoDraw(True)
                    
                    # if image14_HTRU_OD is active this frame...
                    if image14_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image14_HTRU_OD is stopping this frame...
                    if image14_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image14_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image14_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image14_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image14_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image14_HTRU_OD.stopped')
                            # update status
                            image14_HTRU_OD.status = FINISHED
                            image14_HTRU_OD.setAutoDraw(False)
                    
                    # *image15_HTRU_OD* updates
                    
                    # if image15_HTRU_OD is starting this frame...
                    if image15_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.933338-frameTolerance:
                        # keep track of start time/frame for later
                        image15_HTRU_OD.frameNStart = frameN  # exact frame index
                        image15_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image15_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image15_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image15_HTRU_OD.started')
                        # update status
                        image15_HTRU_OD.status = STARTED
                        image15_HTRU_OD.setAutoDraw(True)
                    
                    # if image15_HTRU_OD is active this frame...
                    if image15_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image15_HTRU_OD is stopping this frame...
                    if image15_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image15_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image15_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image15_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image15_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image15_HTRU_OD.stopped')
                            # update status
                            image15_HTRU_OD.status = FINISHED
                            image15_HTRU_OD.setAutoDraw(False)
                    
                    # *image16_HTRU_OD* updates
                    
                    # if image16_HTRU_OD is starting this frame...
                    if image16_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.000005-frameTolerance:
                        # keep track of start time/frame for later
                        image16_HTRU_OD.frameNStart = frameN  # exact frame index
                        image16_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image16_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image16_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image16_HTRU_OD.started')
                        # update status
                        image16_HTRU_OD.status = STARTED
                        image16_HTRU_OD.setAutoDraw(True)
                    
                    # if image16_HTRU_OD is active this frame...
                    if image16_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image16_HTRU_OD is stopping this frame...
                    if image16_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image16_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image16_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image16_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image16_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image16_HTRU_OD.stopped')
                            # update status
                            image16_HTRU_OD.status = FINISHED
                            image16_HTRU_OD.setAutoDraw(False)
                    
                    # *image17_HTRU_OD* updates
                    
                    # if image17_HTRU_OD is starting this frame...
                    if image17_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.066672-frameTolerance:
                        # keep track of start time/frame for later
                        image17_HTRU_OD.frameNStart = frameN  # exact frame index
                        image17_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image17_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image17_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image17_HTRU_OD.started')
                        # update status
                        image17_HTRU_OD.status = STARTED
                        image17_HTRU_OD.setAutoDraw(True)
                    
                    # if image17_HTRU_OD is active this frame...
                    if image17_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image17_HTRU_OD is stopping this frame...
                    if image17_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image17_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image17_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image17_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image17_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image17_HTRU_OD.stopped')
                            # update status
                            image17_HTRU_OD.status = FINISHED
                            image17_HTRU_OD.setAutoDraw(False)
                    
                    # *image18_HTRU_OD* updates
                    
                    # if image18_HTRU_OD is starting this frame...
                    if image18_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.133339-frameTolerance:
                        # keep track of start time/frame for later
                        image18_HTRU_OD.frameNStart = frameN  # exact frame index
                        image18_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image18_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image18_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image18_HTRU_OD.started')
                        # update status
                        image18_HTRU_OD.status = STARTED
                        image18_HTRU_OD.setAutoDraw(True)
                    
                    # if image18_HTRU_OD is active this frame...
                    if image18_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image18_HTRU_OD is stopping this frame...
                    if image18_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image18_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image18_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image18_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image18_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image18_HTRU_OD.stopped')
                            # update status
                            image18_HTRU_OD.status = FINISHED
                            image18_HTRU_OD.setAutoDraw(False)
                    
                    # *image19_HTRU_OD* updates
                    
                    # if image19_HTRU_OD is starting this frame...
                    if image19_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.200006-frameTolerance:
                        # keep track of start time/frame for later
                        image19_HTRU_OD.frameNStart = frameN  # exact frame index
                        image19_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image19_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image19_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image19_HTRU_OD.started')
                        # update status
                        image19_HTRU_OD.status = STARTED
                        image19_HTRU_OD.setAutoDraw(True)
                    
                    # if image19_HTRU_OD is active this frame...
                    if image19_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image19_HTRU_OD is stopping this frame...
                    if image19_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image19_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image19_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image19_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image19_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image19_HTRU_OD.stopped')
                            # update status
                            image19_HTRU_OD.status = FINISHED
                            image19_HTRU_OD.setAutoDraw(False)
                    
                    # *image20_HTRU_OD* updates
                    
                    # if image20_HTRU_OD is starting this frame...
                    if image20_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.266673-frameTolerance:
                        # keep track of start time/frame for later
                        image20_HTRU_OD.frameNStart = frameN  # exact frame index
                        image20_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image20_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image20_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image20_HTRU_OD.started')
                        # update status
                        image20_HTRU_OD.status = STARTED
                        image20_HTRU_OD.setAutoDraw(True)
                    
                    # if image20_HTRU_OD is active this frame...
                    if image20_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image20_HTRU_OD is stopping this frame...
                    if image20_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image20_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image20_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image20_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image20_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image20_HTRU_OD.stopped')
                            # update status
                            image20_HTRU_OD.status = FINISHED
                            image20_HTRU_OD.setAutoDraw(False)
                    
                    # *image21_HTRU_OD* updates
                    
                    # if image21_HTRU_OD is starting this frame...
                    if image21_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.333340-frameTolerance:
                        # keep track of start time/frame for later
                        image21_HTRU_OD.frameNStart = frameN  # exact frame index
                        image21_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image21_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image21_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image21_HTRU_OD.started')
                        # update status
                        image21_HTRU_OD.status = STARTED
                        image21_HTRU_OD.setAutoDraw(True)
                    
                    # if image21_HTRU_OD is active this frame...
                    if image21_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image21_HTRU_OD is stopping this frame...
                    if image21_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image21_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image21_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image21_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image21_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image21_HTRU_OD.stopped')
                            # update status
                            image21_HTRU_OD.status = FINISHED
                            image21_HTRU_OD.setAutoDraw(False)
                    
                    # *image22_HTRU_OD* updates
                    
                    # if image22_HTRU_OD is starting this frame...
                    if image22_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.400007-frameTolerance:
                        # keep track of start time/frame for later
                        image22_HTRU_OD.frameNStart = frameN  # exact frame index
                        image22_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image22_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image22_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image22_HTRU_OD.started')
                        # update status
                        image22_HTRU_OD.status = STARTED
                        image22_HTRU_OD.setAutoDraw(True)
                    
                    # if image22_HTRU_OD is active this frame...
                    if image22_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image22_HTRU_OD is stopping this frame...
                    if image22_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image22_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image22_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image22_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image22_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image22_HTRU_OD.stopped')
                            # update status
                            image22_HTRU_OD.status = FINISHED
                            image22_HTRU_OD.setAutoDraw(False)
                    
                    # *image23_HTRU_OD* updates
                    
                    # if image23_HTRU_OD is starting this frame...
                    if image23_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.466674-frameTolerance:
                        # keep track of start time/frame for later
                        image23_HTRU_OD.frameNStart = frameN  # exact frame index
                        image23_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image23_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image23_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image23_HTRU_OD.started')
                        # update status
                        image23_HTRU_OD.status = STARTED
                        image23_HTRU_OD.setAutoDraw(True)
                    
                    # if image23_HTRU_OD is active this frame...
                    if image23_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image23_HTRU_OD is stopping this frame...
                    if image23_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image23_HTRU_OD.tStartRefresh + 0.066667-frameTolerance:
                            # keep track of stop time/frame for later
                            image23_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image23_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image23_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image23_HTRU_OD.stopped')
                            # update status
                            image23_HTRU_OD.status = FINISHED
                            image23_HTRU_OD.setAutoDraw(False)
                    
                    # *image24_HTRU_OD* updates
                    
                    # if image24_HTRU_OD is starting this frame...
                    if image24_HTRU_OD.status == NOT_STARTED and tThisFlip >= 1.533341-frameTolerance:
                        # keep track of start time/frame for later
                        image24_HTRU_OD.frameNStart = frameN  # exact frame index
                        image24_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image24_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image24_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image24_HTRU_OD.started')
                        # update status
                        image24_HTRU_OD.status = STARTED
                        image24_HTRU_OD.setAutoDraw(True)
                    
                    # if image24_HTRU_OD is active this frame...
                    if image24_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image24_HTRU_OD is stopping this frame...
                    if image24_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image24_HTRU_OD.tStartRefresh + 0.066659-frameTolerance:
                            # keep track of stop time/frame for later
                            image24_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image24_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image24_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image24_HTRU_OD.stopped')
                            # update status
                            image24_HTRU_OD.status = FINISHED
                            image24_HTRU_OD.setAutoDraw(False)
                    
                    # *image_Frame_HTRU_OD* updates
                    
                    # if image_Frame_HTRU_OD is starting this frame...
                    if image_Frame_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Frame_HTRU_OD.frameNStart = frameN  # exact frame index
                        image_Frame_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image_Frame_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Frame_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Frame_HTRU_OD.started')
                        # update status
                        image_Frame_HTRU_OD.status = STARTED
                        image_Frame_HTRU_OD.setAutoDraw(True)
                    
                    # if image_Frame_HTRU_OD is active this frame...
                    if image_Frame_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Frame_HTRU_OD is stopping this frame...
                    if image_Frame_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Frame_HTRU_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Frame_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image_Frame_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Frame_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Frame_HTRU_OD.stopped')
                            # update status
                            image_Frame_HTRU_OD.status = FINISHED
                            image_Frame_HTRU_OD.setAutoDraw(False)
                    
                    # *image_Cue_HTRU_OD* updates
                    
                    # if image_Cue_HTRU_OD is starting this frame...
                    if image_Cue_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Cue_HTRU_OD.frameNStart = frameN  # exact frame index
                        image_Cue_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image_Cue_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Cue_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cue_HTRU_OD.started')
                        # update status
                        image_Cue_HTRU_OD.status = STARTED
                        image_Cue_HTRU_OD.setAutoDraw(True)
                    
                    # if image_Cue_HTRU_OD is active this frame...
                    if image_Cue_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Cue_HTRU_OD is stopping this frame...
                    if image_Cue_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Cue_HTRU_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Cue_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image_Cue_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Cue_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Cue_HTRU_OD.stopped')
                            # update status
                            image_Cue_HTRU_OD.status = FINISHED
                            image_Cue_HTRU_OD.setAutoDraw(False)
                    
                    # *image_Cross_HTRU_OD* updates
                    
                    # if image_Cross_HTRU_OD is starting this frame...
                    if image_Cross_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                        # keep track of start time/frame for later
                        image_Cross_HTRU_OD.frameNStart = frameN  # exact frame index
                        image_Cross_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image_Cross_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Cross_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cross_HTRU_OD.started')
                        # update status
                        image_Cross_HTRU_OD.status = STARTED
                        image_Cross_HTRU_OD.setAutoDraw(True)
                    
                    # if image_Cross_HTRU_OD is active this frame...
                    if image_Cross_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Cross_HTRU_OD is stopping this frame...
                    if image_Cross_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Cross_HTRU_OD.tStartRefresh + 1.6-frameTolerance:
                            # keep track of stop time/frame for later
                            image_Cross_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image_Cross_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Cross_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Cross_HTRU_OD.stopped')
                            # update status
                            image_Cross_HTRU_OD.status = FINISHED
                            image_Cross_HTRU_OD.setAutoDraw(False)
                    
                    # *image_Tar_HTRU_OD* updates
                    
                    # if image_Tar_HTRU_OD is starting this frame...
                    if image_Tar_HTRU_OD.status == NOT_STARTED and tThisFlip >= (1.6 - my_randtartime[my_randtartime_counter])-frameTolerance:   ### CUSTOM START AND END 
                        # keep track of start time/frame for later
                        image_Tar_HTRU_OD.frameNStart = frameN  # exact frame index
                        image_Tar_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        image_Tar_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(image_Tar_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Tar_HTRU_OD.started')
                        # update status
                        image_Tar_HTRU_OD.status = STARTED
                        image_Tar_HTRU_OD.setAutoDraw(True)
                    
                    # if image_Tar_HTRU_OD is active this frame...
                    if image_Tar_HTRU_OD.status == STARTED:
                        # update params
                        pass
                    
                    # if image_Tar_HTRU_OD is stopping this frame...
                    if image_Tar_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > image_Tar_HTRU_OD.tStartRefresh + my_randtartime[my_randtartime_counter]-frameTolerance:         ### CUSTOM START AND END 
                            # keep track of stop time/frame for later
                            image_Tar_HTRU_OD.tStop = t  # not accounting for scr refresh
                            image_Tar_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            image_Tar_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'image_Tar_HTRU_OD.stopped')
                            # update status
                            image_Tar_HTRU_OD.status = FINISHED
                            image_Tar_HTRU_OD.setAutoDraw(False)
                    
                    # *key_HTRU_OD* updates
                    waitOnFlip = False
                    
                    # if key_HTRU_OD is starting this frame...
                    if key_HTRU_OD.status == NOT_STARTED and tThisFlip >= 0.1-frameTolerance:
                        # keep track of start time/frame for later
                        key_HTRU_OD.frameNStart = frameN  # exact frame index
                        key_HTRU_OD.tStart = t  # local t and not account for scr refresh
                        key_HTRU_OD.tStartRefresh = tThisFlipGlobal  # on global time
                        win.timeOnFlip(key_HTRU_OD, 'tStartRefresh')  # time at next scr refresh
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'key_HTRU_OD.started')
                        # update status
                        key_HTRU_OD.status = STARTED
                        # keyboard checking is just starting
                        waitOnFlip = True
                        win.callOnFlip(key_HTRU_OD.clock.reset)  # t=0 on next screen flip
                        win.callOnFlip(key_HTRU_OD.clearEvents, eventType='keyboard')  # clear events on next screen flip
                    
                    # if key_HTRU_OD is stopping this frame...
                    if key_HTRU_OD.status == STARTED:
                        # is it time to stop? (based on global clock, using actual start)
                        if tThisFlipGlobal > key_HTRU_OD.tStartRefresh + 1.5-frameTolerance:
                            # keep track of stop time/frame for later
                            key_HTRU_OD.tStop = t  # not accounting for scr refresh
                            key_HTRU_OD.tStopRefresh = tThisFlipGlobal  # on global time
                            key_HTRU_OD.frameNStop = frameN  # exact frame index
                            # add timestamp to datafile
                            thisExp.timestampOnFlip(win, 'key_HTRU_OD.stopped')
                            # update status
                            key_HTRU_OD.status = FINISHED
                            key_HTRU_OD.status = FINISHED
                    if key_HTRU_OD.status == STARTED and not waitOnFlip:
                        theseKeys = key_HTRU_OD.getKeys(keyList=['1'], ignoreKeys=["escape"], waitRelease=False)
                        _key_HTRU_OD_allKeys.extend(theseKeys)
                        if len(_key_HTRU_OD_allKeys):
                            key_HTRU_OD.keys = _key_HTRU_OD_allKeys[0].name  # just the first key pressed
                            key_HTRU_OD.rt = _key_HTRU_OD_allKeys[0].rt
                            key_HTRU_OD.duration = _key_HTRU_OD_allKeys[0].duration
                            # was this correct?
                            ### CUSTOM START ###
                            #if (key_HTRU.keys == str(corr_resp)) or (key_HTRU.keys == corr_resp):
                            if (key_HTRU_OD.keys == str(my_corrResp_GR[my_outerloopcounter][my_TDAGR_counter])) or (key_HTRU_OD.keys == my_corrResp_GR[my_outerloopcounter][my_TDAGR_counter]):
                                key_HTRU_OD.corr = 1
                            else:
                                key_HTRU_OD.corr = 0
                    
                    # check for quit (typically the Esc key)
                    if defaultKeyboard.getKeys(keyList=["escape"]):
                        thisExp.status = FINISHED
                    if thisExp.status == FINISHED or endExpNow:
                        endExperiment(thisExp, win=win)
                        return
                    # pause experiment here if requested
                    if thisExp.status == PAUSED:
                        pauseExperiment(
                            thisExp=thisExp, 
                            win=win, 
                            timers=[routineTimer], 
                            playbackComponents=[]
                        )
                        # skip the frame we paused on
                        continue
                    
                    # check if all components have finished
                    if not continueRoutine:  # a component has requested a forced-end of Routine
                        HTRU_OD.forceEnded = routineForceEnded = True
                        break
                    continueRoutine = False  # will revert to True if at least one component still running
                    for thisComponent in HTRU_OD.components:
                        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                            continueRoutine = True
                            break  # at least one component has not yet finished
                    
                    # refresh the screen
                    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                        win.flip()
                
                my_randtartime_counter = my_randtartime_counter + 1          ### CUSTOM START AND END
                
                # --- Ending Routine "HTRU_OD" ---
                for thisComponent in HTRU_OD.components:
                    if hasattr(thisComponent, "setAutoDraw"):
                        thisComponent.setAutoDraw(False)
                # store stop times for HTRU_OD
                HTRU_OD.tStop = globalClock.getTime(format='float')
                HTRU_OD.tStopRefresh = tThisFlipGlobal
                thisExp.addData('HTRU_OD.stopped', HTRU_OD.tStop)
                # check responses
                if key_HTRU_OD.keys in ['', [], None]:  # No response was made
                    key_HTRU_OD.keys = None
                    # was no response the correct answer?!
                    if str(my_corrResp_GR[my_outerloopcounter][my_TDAGR_counter]).lower() == 'none': # CUSTOM START & END
                       key_HTRU_OD.corr = 1;  # correct non-response
                    else:
                       key_HTRU_OD.corr = 0;  # failed to respond (incorrectly)
                # store data for Trials_HTRU_OD (TrialHandler)
                Trials_HTRU_OD.addData('key_HTRU_OD.keys',key_HTRU_OD.keys)
                Trials_HTRU_OD.addData('key_HTRU_OD.corr', key_HTRU_OD.corr)
                if key_HTRU_OD.keys != None:  # we had a response
                    Trials_HTRU_OD.addData('key_HTRU_OD.rt', key_HTRU_OD.rt)
                    Trials_HTRU_OD.addData('key_HTRU_OD.duration', key_HTRU_OD.duration)
                try:
                    if image1_HTRU_OD.tStopRefresh is not None:
                        duration_val = image1_HTRU_OD.tStopRefresh - image1_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image1_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image1_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image1_HTRU_OD).__name__,
                        trial_type='image1_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image1_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image2_HTRU_OD.tStopRefresh is not None:
                        duration_val = image2_HTRU_OD.tStopRefresh - image2_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image2_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image2_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image2_HTRU_OD).__name__,
                        trial_type='image2_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image2_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image3_HTRU_OD.tStopRefresh is not None:
                        duration_val = image3_HTRU_OD.tStopRefresh - image3_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image3_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image3_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image3_HTRU_OD).__name__,
                        trial_type='image3_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image3_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image4_HTRU_OD.tStopRefresh is not None:
                        duration_val = image4_HTRU_OD.tStopRefresh - image4_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image4_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image4_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image4_HTRU_OD).__name__,
                        trial_type='image4_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image4_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image5_HTRU_OD.tStopRefresh is not None:
                        duration_val = image5_HTRU_OD.tStopRefresh - image5_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image5_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image5_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image5_HTRU_OD).__name__,
                        trial_type='image5_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image5_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image6_HTRU_OD.tStopRefresh is not None:
                        duration_val = image6_HTRU_OD.tStopRefresh - image6_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image6_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image6_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image6_HTRU_OD).__name__,
                        trial_type='image6_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image6_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image7_HTRU_OD.tStopRefresh is not None:
                        duration_val = image7_HTRU_OD.tStopRefresh - image7_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image7_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image7_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image7_HTRU_OD).__name__,
                        trial_type='image7_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image7_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image8_HTRU_OD.tStopRefresh is not None:
                        duration_val = image8_HTRU_OD.tStopRefresh - image8_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image8_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image8_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image8_HTRU_OD).__name__,
                        trial_type='image8_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image8_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image9_HTRU_OD.tStopRefresh is not None:
                        duration_val = image9_HTRU_OD.tStopRefresh - image9_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image9_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image9_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image9_HTRU_OD).__name__,
                        trial_type='image9_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image9_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image10_HTRU_OD.tStopRefresh is not None:
                        duration_val = image10_HTRU_OD.tStopRefresh - image10_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image10_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image10_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image10_HTRU_OD).__name__,
                        trial_type='image10_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image10_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image11_HTRU_OD.tStopRefresh is not None:
                        duration_val = image11_HTRU_OD.tStopRefresh - image11_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image11_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image11_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image11_HTRU_OD).__name__,
                        trial_type='image11_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image11_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image12_HTRU_OD.tStopRefresh is not None:
                        duration_val = image12_HTRU_OD.tStopRefresh - image12_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image12_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image12_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image12_HTRU_OD).__name__,
                        trial_type='image12_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image12_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image13_HTRU_OD.tStopRefresh is not None:
                        duration_val = image13_HTRU_OD.tStopRefresh - image13_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image13_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image13_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image13_HTRU_OD).__name__,
                        trial_type='image13_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image13_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image14_HTRU_OD.tStopRefresh is not None:
                        duration_val = image14_HTRU_OD.tStopRefresh - image14_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image14_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image14_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image14_HTRU_OD).__name__,
                        trial_type='image14_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image14_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image15_HTRU_OD.tStopRefresh is not None:
                        duration_val = image15_HTRU_OD.tStopRefresh - image15_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image15_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image15_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image15_HTRU_OD).__name__,
                        trial_type='image15_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image15_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image16_HTRU_OD.tStopRefresh is not None:
                        duration_val = image16_HTRU_OD.tStopRefresh - image16_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image16_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image16_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image16_HTRU_OD).__name__,
                        trial_type='image16_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image16_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image17_HTRU_OD.tStopRefresh is not None:
                        duration_val = image17_HTRU_OD.tStopRefresh - image17_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image17_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image17_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image17_HTRU_OD).__name__,
                        trial_type='image17_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image17_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image18_HTRU_OD.tStopRefresh is not None:
                        duration_val = image18_HTRU_OD.tStopRefresh - image18_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image18_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image18_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image18_HTRU_OD).__name__,
                        trial_type='image18_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image18_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image19_HTRU_OD.tStopRefresh is not None:
                        duration_val = image19_HTRU_OD.tStopRefresh - image19_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image19_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image19_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image19_HTRU_OD).__name__,
                        trial_type='image19_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image19_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image20_HTRU_OD.tStopRefresh is not None:
                        duration_val = image20_HTRU_OD.tStopRefresh - image20_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image20_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image20_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image20_HTRU_OD).__name__,
                        trial_type='image20_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image20_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image21_HTRU_OD.tStopRefresh is not None:
                        duration_val = image21_HTRU_OD.tStopRefresh - image21_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image21_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image21_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image21_HTRU_OD).__name__,
                        trial_type='image21_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image21_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image22_HTRU_OD.tStopRefresh is not None:
                        duration_val = image22_HTRU_OD.tStopRefresh - image22_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image22_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image22_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image22_HTRU_OD).__name__,
                        trial_type='image22_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image22_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image23_HTRU_OD.tStopRefresh is not None:
                        duration_val = image23_HTRU_OD.tStopRefresh - image23_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image23_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image23_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image23_HTRU_OD).__name__,
                        trial_type='image23_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image23_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image24_HTRU_OD.tStopRefresh is not None:
                        duration_val = image24_HTRU_OD.tStopRefresh - image24_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image24_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image24_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image24_HTRU_OD).__name__,
                        trial_type='image24_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image24_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image_Cue_HTRU_OD.tStopRefresh is not None:
                        duration_val = image_Cue_HTRU_OD.tStopRefresh - image_Cue_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image_Cue_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image_Cue_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image_Cue_HTRU_OD).__name__,
                        trial_type='image_Cue_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image_Cue_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if image_Tar_HTRU_OD.tStopRefresh is not None:
                        duration_val = image_Tar_HTRU_OD.tStopRefresh - image_Tar_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - image_Tar_HTRU_OD.tStartRefresh
                    bids_event = BIDSTaskEvent(
                        onset=image_Tar_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        event_type=type(image_Tar_HTRU_OD).__name__,
                        trial_type='image_Tar_HTRU_OD',
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_image_Tar_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                try:
                    if key_HTRU_OD.tStopRefresh is not None:
                        duration_val = key_HTRU_OD.tStopRefresh - key_HTRU_OD.tStartRefresh
                    else:
                        duration_val = thisExp.thisEntry['HTRU_OD.stopped'] - key_HTRU_OD.tStartRefresh
                    if hasattr(key_HTRU_OD, 'rt'):
                        rt_val = key_HTRU_OD.rt
                    else:
                        rt_val = None
                        logging.warning('The linked component "key_HTRU_OD" does not have a reaction time(.rt) attribute. Unable to link BIDS response_time to this component. Please verify the component settings.')
                    bids_event = BIDSTaskEvent(
                        onset=key_HTRU_OD.tStartRefresh,
                        duration=duration_val,
                        response_time=rt_val,
                        event_type=type(key_HTRU_OD).__name__,
                        trial_type='key_HTRU_OD',
                        value=key_HTRU_OD.corr,
                    )
                    if bids_handler:
                        bids_handler.addEvent(bids_event)
                    else:
                        Trials_HTRU_OD.addData('bidsEvent_key_HTRU_OD.event', bids_event)
                except BIDSError as e:
                    print(f"[psychopy-bids(event)] An error occurred when creating BIDS event: {e}")
                # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
                if HTRU_OD.maxDurationReached:
                    routineTimer.addTime(-HTRU_OD.maxDuration)
                elif HTRU_OD.forceEnded:
                    routineTimer.reset()
                else:
                    routineTimer.addTime(-1.600000)
                thisExp.nextEntry()
                
                ## CUSTOM START 
                my_TDAGR_counter = my_TDAGR_counter + 1 
                ## CUSTOM END 
                
            # completed 1.0 repeats of 'Trials_HTRU_OD'
            
            if thisSession is not None:
                # if running in a Session with a Liaison client, send data up to now
                thisSession.sendExperimentData()
            # get names of stimulus parameters
            if Trials_HTRU_OD.trialList in ([], [None], None):
                params = []
            else:
                params = Trials_HTRU_OD.trialList[0].keys()
            # save data for this loop
            Trials_HTRU_OD.saveAsExcel(filename + '.xlsx', sheetName='Trials_HTRU_OD',
                stimOut=params,
                dataOut=['n','all_mean','all_std', 'all_raw'])
            Trials_HTRU_OD.saveAsText(filename + 'Trials_HTRU_OD.csv', delim=',',
                stimOut=params,
                dataOut=['n','all_mean','all_std', 'all_raw'])
            
            # --- Prepare to start Routine "Break" ---
            # create an object to store info about Routine Break
            Break = data.Routine(
                name='Break',
                components=[image_Frame_Break, image_Cross_Break],
            )
            Break.status = NOT_STARTED
            continueRoutine = True
            # update component parameters for each repeat
            # store start times for Break
            Break.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
            Break.tStart = globalClock.getTime(format='float')
            Break.status = STARTED
            thisExp.addData('Break.started', Break.tStart)
            Break.maxDuration = None
            # keep track of which components have finished
            BreakComponents = Break.components
            for thisComponent in Break.components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "Break" ---
            # if trial has changed, end Routine now
            if isinstance(Outerloop, data.TrialHandler2) and thisOuterloop.thisN != Outerloop.thisTrial.thisN:
                continueRoutine = False
            Break.forceEnded = routineForceEnded = not continueRoutine
            while continueRoutine and routineTimer.getTime() < 1.0:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *image_Frame_Break* updates
                
                # if image_Frame_Break is starting this frame...
                if image_Frame_Break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    image_Frame_Break.frameNStart = frameN  # exact frame index
                    image_Frame_Break.tStart = t  # local t and not account for scr refresh
                    image_Frame_Break.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_Frame_Break, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_Frame_Break.started')
                    # update status
                    image_Frame_Break.status = STARTED
                    image_Frame_Break.setAutoDraw(True)
                
                # if image_Frame_Break is active this frame...
                if image_Frame_Break.status == STARTED:
                    # update params
                    pass
                
                # if image_Frame_Break is stopping this frame...
                if image_Frame_Break.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_Frame_Break.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        image_Frame_Break.tStop = t  # not accounting for scr refresh
                        image_Frame_Break.tStopRefresh = tThisFlipGlobal  # on global time
                        image_Frame_Break.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Frame_Break.stopped')
                        # update status
                        image_Frame_Break.status = FINISHED
                        image_Frame_Break.setAutoDraw(False)
                
                # *image_Cross_Break* updates
                
                # if image_Cross_Break is starting this frame...
                if image_Cross_Break.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    image_Cross_Break.frameNStart = frameN  # exact frame index
                    image_Cross_Break.tStart = t  # local t and not account for scr refresh
                    image_Cross_Break.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image_Cross_Break, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image_Cross_Break.started')
                    # update status
                    image_Cross_Break.status = STARTED
                    image_Cross_Break.setAutoDraw(True)
                
                # if image_Cross_Break is active this frame...
                if image_Cross_Break.status == STARTED:
                    # update params
                    pass
                
                # if image_Cross_Break is stopping this frame...
                if image_Cross_Break.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image_Cross_Break.tStartRefresh + 1.0-frameTolerance:
                        # keep track of stop time/frame for later
                        image_Cross_Break.tStop = t  # not accounting for scr refresh
                        image_Cross_Break.tStopRefresh = tThisFlipGlobal  # on global time
                        image_Cross_Break.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image_Cross_Break.stopped')
                        # update status
                        image_Cross_Break.status = FINISHED
                        image_Cross_Break.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if defaultKeyboard.getKeys(keyList=["escape"]):
                    thisExp.status = FINISHED
                if thisExp.status == FINISHED or endExpNow:
                    endExperiment(thisExp, win=win)
                    return
                # pause experiment here if requested
                if thisExp.status == PAUSED:
                    pauseExperiment(
                        thisExp=thisExp, 
                        win=win, 
                        timers=[routineTimer], 
                        playbackComponents=[]
                    )
                    # skip the frame we paused on
                    continue
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    Break.forceEnded = routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in Break.components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "Break" ---
            for thisComponent in Break.components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # store stop times for Break
            Break.tStop = globalClock.getTime(format='float')
            Break.tStopRefresh = tThisFlipGlobal
            thisExp.addData('Break.stopped', Break.tStop)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if Break.maxDurationReached:
                routineTimer.addTime(-Break.maxDuration)
            elif Break.forceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.000000)
            
        #Custom-Comment: End TDA_GR    
        
        #--- CUSTOM START ---
        my_outerloopcounter = my_outerloopcounter + 1
        #--- CUSTOM END ---
    # completed 2.0 repeats of 'Outerloop'
    
    thisExp.nextEntry()
    # the Routine "bidsExport_cva25_con_OD" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    ignore_list = [
        'participant',
        'session',
        'date',
        'expName',
        'psychopyVersion',
        'OS',
        'frameRate'
    ]
    participant_info = {
        key: thisExp.extraInfo[key]
        for key in thisExp.extraInfo
        if key not in ignore_list
    }
    # write tsv file and update
    try:
        if bids_handler.events:
            bids_handler.writeEvents(participant_info, add_stimuli=True, execute_sidecar=True, generate_hed_metadata=True)
    except Exception as e:
        print(f"[psychopy-bids(settings)] An error occurred when writing BIDS events: {e}")
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
